import { Link } from "@tanstack/react-router";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { ChevronRight, TriangleAlert } from "lucide-react";
import { useState } from "react";
import { createPortal } from "react-dom";
import { HomeAction } from "@/components/coming-soon";
import { CoachDeniedCard } from "@/components/coach-denied";
import { Button } from "@/components/ui/button";
import { archivePlanningYear, type PendingRequest, type PendingTeam, type Profile, type SeasonCard, type SeasonRollover, type Weekend } from "@/lib/pbi/api";
import { seasonLabel, defaultSeasonWindow, finalizeIsDue, formatAgeGroups, formatMonthDay, formatSeasonSpan, formatWeekendRange, FIRST_SEASON_YEAR, isoDateFromLocal } from "@/lib/pbi/weekends";
import { MAX_COACH_REQUESTS } from "@/lib/pbi/coach-request";
import { ROLE_COPY } from "@/lib/pbi/roles";
import { poolScheduleChecks, type ReadyCheck } from "@/lib/pbi/rules";

function firstPitchMs(weekend: Weekend): number {
  const [y, m, d] = weekend.startDate.split("-").map(Number);
  const [hh, mm] = (weekend.rules.firstPitch || "08:00").split(":").map(Number);
  return new Date(y || 0, (m || 1) - 1, d || 1, hh || 0, mm || 0, 0, 0).getTime();
}

function tournamentEnded(weekend: Weekend, now: Date): boolean {
  const [y, m, d] = weekend.endDate.split("-").map(Number);
  return now.getTime() > new Date(y || 0, (m || 1) - 1, d || 1, 23, 59, 59, 999).getTime();
}

function activeTournaments(weekends: Weekend[], now = new Date()) {
  return weekends
    .filter((weekend) => weekend.lifecycle !== "announced" && !tournamentEnded(weekend, now))
    .sort((a, b) => firstPitchMs(a) - firstPitchMs(b));
}

function missingFor(weekend: Weekend): ReadyCheck[] {
  return poolScheduleChecks({
    ageGroups: weekend.ageGroups,
    approvedByAge: weekend.approvedByAge ?? {},
    locationCount: weekend.locationCount,
    minTeams: weekend.rules.minTeams,
    hasBracket: weekend.hasBracket,
  }).items.filter((item) => !item.ok && item.id !== "bracket");
}

function MissingDialog({
  weekend,
  items,
  onClose,
}: {
  weekend: Weekend;
  items: ReadyCheck[];
  onClose: () => void;
}) {
  if (typeof document === "undefined") return null;
  return createPortal(
    <div className="fixed inset-0 z-[80] flex items-end justify-center bg-scrim p-4 sm:items-center" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="missing-dialog-title"
        className="w-full max-w-md rounded-lg border border-line bg-bg p-4 text-fg shadow-lg"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="flex items-center justify-between gap-3">
          <h2 id="missing-dialog-title" className="font-display text-2xl font-bold uppercase">
            What's missing
          </h2>
          <Button type="button" variant="ghost" className="px-2 text-muted" onClick={onClose}>
            Close
          </Button>
        </div>
        <p className="mt-1 text-sm text-muted">{weekend.name}</p>
        <ul className="mt-4 space-y-2">
          {items.map((item) => (
            <li key={item.id}>
              <Link
                to={item.to}
                params={{ weekendId: String(weekend.id) }}
                className="block rounded-md bg-warn-bg px-3 py-2 text-sm font-medium"
                onClick={onClose}
              >
                <span className="block">Missing — {item.label}</span>
                <span className="mt-1 block text-xs font-bold uppercase tracking-wide">Open →</span>
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </div>,
    document.body,
  );
}

function dateStamp(start: string) {
  const [ys, ms, ds] = start.split("-").map(Number);
  const startDt = new Date(ys || 0, (ms || 1) - 1, ds || 1);
  return {
    month: startDt.toLocaleDateString("en-US", { month: "short" }),
    day: ds ? String(ds) : "—",
  };
}

function tournamentFacts(weekend: Weekend) {
  if (weekend.lifecycle === "announced") return ["Announced"];
  const facts: string[] = [];
  if (weekend.ageGroups.length > 0) facts.push(formatAgeGroups(weekend.ageGroups));
  facts.push(weekend.approvedCount === 1 ? "1 team" : `${weekend.approvedCount} teams`);
  if (weekend.rules.fieldCount > 0) {
    facts.push(weekend.rules.fieldCount === 1 ? "1 field" : `${weekend.rules.fieldCount} fields`);
  } else if (weekend.locationCount > 0) {
    facts.push(weekend.locationCount === 1 ? "1 park" : `${weekend.locationCount} parks`);
  }
  return facts;
}

function TournamentRows({ items }: { items: Weekend[] }) {
  const [openId, setOpenId] = useState<number | null>(null);
  const open = items.find((weekend) => weekend.id === openId) ?? null;
  const openItems = open ? missingFor(open) : [];
  return (
    <>
      <ul className="space-y-2">
        {items.map((weekend) => {
          const missing = weekend.lifecycle === "announced" ? [] : missingFor(weekend);
          const stamp = dateStamp(weekend.startDate);
          const facts = tournamentFacts(weekend);
          return (
            <li
              key={weekend.id}
              className="overflow-hidden rounded-lg border border-line bg-surface transition-colors duration-150 hover:border-primary"
            >
              <Link
                to="/weekends/$weekendId"
                params={{ weekendId: String(weekend.id) }}
                className="flex items-start gap-3 px-3 py-3"
              >
                <span className="grid h-14 w-14 shrink-0 place-items-center rounded-md bg-sheet-surface text-center leading-none">
                  <span className="text-xs font-bold uppercase tracking-wide text-muted">{stamp.month}</span>
                  <span className="mt-1 font-display text-lg font-bold leading-none tracking-normal">{stamp.day}</span>
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-base font-semibold leading-tight">{weekend.name}</span>
                  <span className="mt-0.5 block text-sm text-muted">
                    {formatWeekendRange(weekend.startDate, weekend.endDate)}
                  </span>
                  <span className="mt-1.5 flex flex-wrap gap-1">
                    {facts.map((fact) => (
                      <span
                        key={fact}
                        className="inline-flex items-center rounded-md bg-sheet-surface px-1.5 py-0.5 text-xs font-semibold text-fg"
                      >
                        {fact}
                      </span>
                    ))}
                  </span>
                </span>
                <ChevronRight className="mt-1 h-5 w-5 shrink-0 text-muted" aria-hidden />
              </Link>
              {missing.length > 0 ? (
                <div className="border-t border-line px-3 py-2">
                  <button
                    type="button"
                    className="inline-flex min-h-9 items-center gap-1.5 rounded-md bg-warn-bg px-2.5 text-sm font-semibold text-fg"
                    aria-label={`${missing.length} missing for ${weekend.name}`}
                    onClick={() => setOpenId(weekend.id)}
                  >
                    <TriangleAlert className="h-4 w-4 shrink-0" strokeWidth={2.25} />
                    {missing.length === 1 ? "1 thing missing" : `${missing.length} things missing`}
                  </button>
                </div>
              ) : null}
            </li>
          );
        })}
      </ul>
      {open && openItems.length > 0 ? (
        <MissingDialog weekend={open} items={openItems} onClose={() => setOpenId(null)} />
      ) : null}
    </>
  );
}

function SectionCount({ count }: { count: number }) {
  return (
    <span className="grid h-7 min-w-7 place-items-center rounded-full border border-line bg-surface px-2 text-sm font-bold">
      {count}
    </span>
  );
}

function StatusBanner({ profile }: { profile: Profile }) {
  if (profile.requestStatus === "pending") {
    const label = profile.requestedRole === "admin" ? "Admin" : "Coach";
    return (
      <Link to="/notifications" className="block rounded-md bg-warn-bg px-4 py-3 text-fg">
        <span className="block font-display text-xl font-bold uppercase">{label} access pending</span>
        <span className="mt-1 block text-sm font-medium">
          An Admin still has to approve {label} tools. You can use Parent tools until then. Tap for status.
        </span>
      </Link>
    );
  }
  if (profile.requestStatus === "denied" && profile.requestedRole === "coach") {
    return <CoachDeniedCard profile={profile} />;
  }
  if (profile.requestStatus === "denied") {
    const label = profile.requestedRole === "admin" ? "Admin" : "Coach";
    return (
      <Link to="/notifications" className="block rounded-md bg-warn-bg px-4 py-3 text-sm font-medium text-fg">
        {label} access was denied. You still have Parent tools. See Notifications.
      </Link>
    );
  }
  return null;
}

function ParentLayout({
  profile,
  greeting,
}: {
  profile: Profile;
  greeting: string;
}) {
  return (
    <div className="space-y-4">
      <h1 className="font-display text-4xl font-bold uppercase">{greeting}</h1>
      <StatusBanner profile={profile} />
      <HomeAction title="My athletes" hint="Coming soon — add the kids you follow." muted />
      <Link to="/schedule" className="block">
        <HomeAction title="Upcoming games" hint="Field, time, and opponent." />
      </Link>
    </div>
  );
}

export function ParentHome({ profile }: { profile: Profile }) {
  return <ParentLayout profile={profile} greeting="Parent home" />;
}

export function AthleteHome() {
  return (
    <div className="space-y-4">
      <h1 className="font-display text-4xl font-bold uppercase">Athlete home</h1>
      <HomeAction title="My team" hint="Coming soon — roster and coaches." muted />
      <Link to="/schedule" className="block">
        <HomeAction title="Upcoming games" hint="When and where you play." />
      </Link>
    </div>
  );
}

export function CoachHome({
  teamCount,
  pendingCount,
}: {
  teamCount: number;
  pendingCount: number;
}) {
  return (
    <div className="space-y-4">
      <h1 className="font-display text-4xl font-bold uppercase">Coach home</h1>
      <Link to="/teams" className="block">
        <HomeAction
          title="My team"
          hint={
            teamCount === 0
              ? "Request a spot in a tournament. Admin has to take you."
              : pendingCount > 0
                ? `${teamCount} team${teamCount === 1 ? "" : "s"} · ${pendingCount} waiting for Admin.`
                : `${teamCount} team${teamCount === 1 ? "" : "s"} on the board.`
          }
        />
      </Link>
      <Link to="/schedule" className="block">
        <HomeAction title="Season schedule" hint="Dates the league is planning. Brackets show up closer to the weekend." />
      </Link>
      <Link to="/schedule" className="block">
        <HomeAction title="Schedule" hint="Fields, times, and the bracket." />
      </Link>
      <HomeAction title="Enter scores" hint="Coming soon." muted />
    </div>
  );
}

function fallbackSeasonCards(): SeasonCard[] {
  return (["spring", "summer", "fall"] as const).map((season) => {
    const year = FIRST_SEASON_YEAR;
    const window = defaultSeasonWindow(season, year);
    return {
      season,
      year,
      label: seasonLabel(season),
      startDate: window.startDate,
      endDate: window.endDate,
      windowLabel: formatSeasonSpan(window.startDate, window.endDate),
      announcedCount: 0,
      pastDeadline: false,
      deadlineCopy: "",
    };
  });
}

function inSeasonWindow(weekend: Weekend, start: string, end: string) {
  return Boolean(start && end) && weekend.startDate <= end && weekend.endDate >= start;
}

export function ArchiveYearPrompt({ rollover }: { rollover: SeasonRollover }) {
  const queryClient = useQueryClient();
  const [sure, setSure] = useState(false);
  const archive = useMutation({
    mutationFn: () => archivePlanningYear(),
    onSuccess: async () => {
      setSure(false);
      await queryClient.invalidateQueries({ queryKey: ["season-cards"] });
      await queryClient.invalidateQueries({ queryKey: ["season-plan"] });
      await queryClient.invalidateQueries({ queryKey: ["weekends"] });
    },
  });
  if (!rollover) return null;
  const error = archive.error instanceof Error ? archive.error.message : null;
  return (
    <div className="space-y-3 rounded-lg border border-line bg-warn-bg px-3 py-3" role="status">
      <p className="text-sm font-semibold">
        Fall ended {formatMonthDay(rollover.fallEnd)}. Archive {rollover.year} and open {rollover.nextYear}?
      </p>
      <p className="text-sm text-muted">
        {rollover.year} stays saved. It comes off these calendars. {rollover.nextYear} starts empty.
      </p>
      {error ? <p className="text-sm">{error}</p> : null}
      {sure ? (
        <div className="flex flex-wrap gap-2">
          <Button type="button" disabled={archive.isPending} onClick={() => archive.mutate()}>
            {archive.isPending ? "Archiving…" : `Yes, archive ${rollover.year}`}
          </Button>
          <Button type="button" variant="outline" disabled={archive.isPending} onClick={() => setSure(false)}>
            Not yet
          </Button>
        </div>
      ) : (
        <Button type="button" onClick={() => setSure(true)}>
          Archive {rollover.year}
        </Button>
      )}
    </div>
  );
}

export function AdminHome({ weekends, seasons, rollover }: { weekends: Weekend[]; seasons: SeasonCard[]; rollover: SeasonRollover }) {
  const active = activeTournaments(weekends);
  const cards = seasons.length > 0 ? seasons : fallbackSeasonCards();
  return (
    <div className="space-y-8">
      <h1 className="font-display text-4xl font-bold uppercase leading-none">Admin home</h1>
      <ArchiveYearPrompt rollover={rollover} />

      <section className="space-y-2">
        <div className="grid grid-cols-3 gap-2">
          {cards.map((card) => {
            const count = weekends.filter((weekend) => inSeasonWindow(weekend, card.startDate, card.endDate)).length;
            const today = isoDateFromLocal(new Date());
            const due = weekends.filter(
              (weekend) =>
                inSeasonWindow(weekend, card.startDate, card.endDate) &&
                weekend.lifecycle === "announced" &&
                finalizeIsDue(today, weekend.startDate),
            ).length;
            return (
              <Link
                key={card.season}
                to="/seasons/$season"
                params={{ season: card.season }}
                search={{ year: card.year }}
                className="flex min-h-24 flex-col items-center justify-center gap-1 rounded-lg border border-line bg-surface px-1 py-3 text-center"
              >
                <span className="font-display text-lg font-bold uppercase leading-none">{card.label}</span>
                <span className="text-xs text-muted">{card.year}</span>
                <span className="text-xs font-semibold">
                  {count === 0 ? "None yet" : count === 1 ? "1 scheduled" : `${count} scheduled`}
                </span>
                {due > 0 ? (
                  <span className="text-xs font-bold uppercase text-fg">{due === 1 ? "1 to finish" : `${due} to finish`}</span>
                ) : null}
              </Link>
            );
          })}
        </div>
        {cards.filter((card) => card.pastDeadline).map((card) => (
          <p key={card.season} className="rounded-md bg-warn-bg px-3 py-2 text-xs">{card.deadlineCopy}</p>
        ))}
        <SeasonDashboard weekends={weekends} cards={cards} />
      </section>

      <section className="space-y-3">
        <div className="flex items-center gap-3">
          <h2 className="font-display text-2xl font-bold uppercase">Active tournaments</h2>
          <SectionCount count={active.length} />
        </div>
        {active.length === 0 ? (
          <p className="rounded-lg border border-dashed border-line bg-surface px-4 py-4 text-sm text-muted">
            None finalized yet.
          </p>
        ) : (
          <TournamentRows items={active} />
        )}
      </section>
    </div>
  );
}

function SeasonDashboard({ weekends, cards }: { weekends: Weekend[]; cards: SeasonCard[] }) {
  const now = new Date();
  const inSeasons = weekends.filter((weekend) => cards.some((card) => inSeasonWindow(weekend, card.startDate, card.endDate)));
  const scheduled = inSeasons.length;
  const complete = inSeasons.filter((weekend) => tournamentEnded(weekend, now)).length;
  const toFinalize = inSeasons.filter((weekend) => weekend.lifecycle === "announced" && !tournamentEnded(weekend, now)).length;
  const finalized = inSeasons.filter((weekend) => weekend.lifecycle !== "announced" && !tournamentEnded(weekend, now)).length;
  const tiles = [
    { n: toFinalize, label: "To finalize", wash: "bg-[#fff6d8]" },
    { n: finalized, label: "Finalized", wash: "bg-[#e8f3fc]" },
    { n: scheduled, label: "Remaining", wash: "bg-surface" },
    { n: complete, label: "Complete", wash: "bg-[#f3f3f3]" },
  ];
  return (
    <div className="overflow-hidden rounded-lg border border-line">
      <div className="grid grid-cols-4">
        {tiles.map((tile, index) => (
          <div
            key={tile.label}
            className={`px-1.5 py-2 text-center ${tile.wash} ${index < tiles.length - 1 ? "border-r border-line" : ""}`}
          >
            <p className="font-display text-lg font-bold leading-none">{tile.n}</p>
            <p className="mt-0.5 text-[10px] font-bold uppercase leading-tight tracking-wide text-muted">{tile.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export function AdminInbox({
  pending,
  pendingTeams,
  busyId,
  busyTeamId,
  onReview,
  onReviewTeam,
}: {
  pending: PendingRequest[];
  pendingTeams: PendingTeam[];
  busyId: number | null;
  busyTeamId: number | null;
  onReview: (id: number, action: "approve" | "deny") => void;
  onReviewTeam: (id: number, action: "approve" | "deny") => void;
}) {
  return (
    <div className="mt-5 space-y-6">
      <section className="space-y-3">
        <h2 className="font-display text-2xl font-bold uppercase">Pending teams</h2>
        {pendingTeams.length === 0 ? (
          <p className="rounded-lg border border-line bg-surface px-4 py-4 text-sm text-muted">
            No team requests. Coaches submit a team, then you take them or not.
          </p>
        ) : (
          pendingTeams.map((team) => (
            <div key={team.id} className="space-y-3 rounded-lg border border-line bg-surface p-4">
              <div>
                <p className="font-display text-2xl font-bold uppercase leading-none">{team.name}</p>
                <p className="mt-2 text-sm font-medium">
                  {team.ageGroup} · {team.tournamentName}
                </p>
                <p className="mt-1 text-sm text-muted">{team.coachEmail}</p>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  type="button"
                  variant="pine"
                  disabled={busyTeamId === team.id}
                  onClick={() => onReviewTeam(team.id, "approve")}
                >
                  Approve
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  disabled={busyTeamId === team.id}
                  onClick={() => onReviewTeam(team.id, "deny")}
                >
                  Deny
                </Button>
              </div>
            </div>
          ))
        )}
      </section>

      <section className="space-y-3">
        <h2 className="font-display text-2xl font-bold uppercase">Pending requests</h2>
        {pending.length === 0 ? (
          <p className="rounded-lg border border-line bg-surface px-4 py-4 text-sm text-muted">
            No one is waiting. New Coach or Admin sign-ups show up here.
          </p>
        ) : (
          pending.map((req) => (
            <div key={req.id} className="space-y-3 rounded-lg border border-line bg-surface p-4">
              <div>
                <p className="font-semibold">{req.email}</p>
                <p className="text-sm text-muted">
                  Wants {ROLE_COPY[req.requestedRole].label} access
                  {req.requestedRole === "coach" && req.attempt > 1
                    ? ` · request ${req.attempt} of ${MAX_COACH_REQUESTS}`
                    : ""}
                </p>
                {req.teamName ? (
                  <p className="mt-2 text-sm">
                    <span className="font-medium">Team:</span> {req.teamName}
                  </p>
                ) : null}
                {req.reason ? (
                  <p className="mt-1 text-sm">
                    <span className="font-medium">Why:</span> {req.reason}
                  </p>
                ) : null}
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  type="button"
                  variant="pine"
                  disabled={busyId === req.id}
                  onClick={() => onReview(req.id, "approve")}
                >
                  Approve
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  disabled={busyId === req.id}
                  onClick={() => onReview(req.id, "deny")}
                >
                  Deny
                </Button>
              </div>
            </div>
          ))
        )}
      </section>
    </div>
  );
}

export function PendingAsParentHome({ profile }: { profile: Profile }) {
  return <ParentLayout profile={profile} greeting="You're in" />;
}
