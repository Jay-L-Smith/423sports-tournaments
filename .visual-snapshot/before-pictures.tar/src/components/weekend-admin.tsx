import { useQuery, useQueryClient, type QueryClient } from "@tanstack/react-query";
import { Link, Navigate, useRouter } from "@tanstack/react-router";
import { ChevronRight } from "lucide-react";
import type { ReactNode } from "react";
import { SessionSkeleton, useAppSession } from "@/components/session-gate";
import { AppShell } from "@/components/shell";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { getWeekend, type WeekendDetail } from "@/lib/pbi/api";
import { lockedBack } from "@/lib/screen-back";

export type WeekendAdminCtx = {
  id: number;
  detail: WeekendDetail;
  queryClient: QueryClient;
  bump: () => void;
};

export function bumpWeekend(queryClient: QueryClient, id: number) {
  void queryClient.invalidateQueries({ queryKey: ["weekend", id] });
  void queryClient.invalidateQueries({ queryKey: ["weekends"] });
  void queryClient.invalidateQueries({ queryKey: ["schedule", id] });
}

export function WeekendAdminFrame({
  weekendId,
  backTo,
  children,
}: {
  weekendId: string;
  backTo: "list" | "hub";
  children: (ctx: WeekendAdminCtx) => ReactNode;
}) {
  const id = Number.parseInt(weekendId, 10);
  const { user, isPending, profile } = useAppSession();
  const queryClient = useQueryClient();
  const router = useRouter();
  const detailQuery = useQuery({
    queryKey: ["weekend", id],
    queryFn: () => getWeekend({ data: { id } }),
    enabled: Boolean(profile?.homeRole === "admin" && Number.isInteger(id) && id > 0),
  });

  if (isPending) return <SessionSkeleton />;
  if (!user) return <RedirectToSignIn />;
  if (!profile || profile.homeRole !== "admin") return <Navigate to="/" />;
  if (!Number.isInteger(id) || id < 1) return <Navigate to="/" />;

  const detail = detailQuery.data;

  return (
    <AppShell homeRole={profile.homeRole}>
      {backTo === "list" ? (
        <button
          type="button"
          onClick={() => {
            const fallback = detail?.season
              ? `/seasons/${detail.season}${detail.seasonYear ? `?year=${detail.seasonYear}` : ""}`
              : "/";
            router.history.push(lockedBack(id, fallback));
          }}
          className="text-sm font-semibold text-primary"
        >
          Back
        </button>
      ) : (
        <Link
          to="/weekends/$weekendId"
          params={{ weekendId: String(id) }}
          className="text-sm font-semibold text-primary"
        >
          ← {detail?.name ?? "Tournament"}
        </Link>
      )}

      {detailQuery.isPending ? (
        <p className="mt-6 text-sm text-muted">Loading this weekend…</p>
      ) : !detail ? (
        <p className="mt-6 rounded-md bg-warn-bg px-3 py-2 text-sm" role="alert">
          {detailQuery.error instanceof Error ? detailQuery.error.message : "Could not load that tournament."}
        </p>
      ) : (
        children({
          id,
          detail,
          queryClient,
          bump: () => bumpWeekend(queryClient, id),
        })
      )}
    </AppShell>
  );
}

export function SectionLink({
  to,
  weekendId,
  title,
  hint,
}: {
  to: "/weekends/$weekendId/edit" | "/weekends/$weekendId/rules" | "/weekends/$weekendId/teams" | "/weekends/$weekendId/locations";
  weekendId: string;
  title: string;
  hint: string;
}) {
  return (
    <Link
      to={to}
      params={{ weekendId }}
      className="flex min-h-11 items-center gap-2 rounded-md border border-line bg-surface px-3 py-2 text-left transition-colors duration-150 hover:border-primary"
    >
      <span className="min-w-0 flex-1">
        <span className="block text-sm font-bold uppercase tracking-wide leading-tight">{title}</span>
        <span className="mt-0.5 block truncate text-xs text-muted">{hint}</span>
      </span>
      <ChevronRight className="h-4 w-4 shrink-0 text-muted" aria-hidden />
    </Link>
  );
}
