import { useMemo, useState, type FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { MondayDateInput } from "@/components/monday-date-input";
import { inclusiveDays, type CoachPath } from "@/lib/pbi/coach";
import {
  assessCapacity,
  bracketClockForFit,
  capacityReport,
  namedDivisions,
  type CapacityInput,
  type EventFormat,
} from "@/lib/pbi/capacity";
import { defaultDivisions, setDivisionCount, type AdvanceMode, type BracketRules } from "@/lib/pbi/rules";
import {
  AGE_GROUPS,
  addDays,
  defaultDayPlan,
  defaultWeekendDates,
  eachIsoDate,
  type AgeGroup,
  type DayPlan,
} from "@/lib/pbi/weekends";

type Step = "name" | "dates" | "size" | "dial" | "confirm";
type SizeDriver = "fields" | "teams";

const FIELD_PATHS: { id: CoachPath; title: string; hint: string }[] = [
  { id: "small", title: "Small", hint: "1–2 fields" },
  { id: "mid", title: "Mid", hint: "3–5 fields" },
  { id: "large", title: "Large", hint: "6–8 fields" },
  { id: "custom", title: "Custom", hint: "Any field count" },
];

const TEAM_PATHS: { id: CoachPath; title: string; hint: string }[] = [
  { id: "small", title: "Small", hint: "3–12 teams" },
  { id: "mid", title: "Mid", hint: "13–24 teams" },
  { id: "large", title: "Large", hint: "25–36 teams" },
  { id: "custom", title: "Custom", hint: "Any team count" },
];

const FIELD_BAND: Record<CoachPath, { min: number; max: number; start: number }> = {
  small: { min: 1, max: 2, start: 1 },
  mid: { min: 3, max: 5, start: 3 },
  large: { min: 6, max: 8, start: 6 },
  custom: { min: 1, max: 12, start: 2 },
};

const TEAM_BAND: Record<Exclude<CoachPath, "custom">, { min: number; max: number; start: number }> = {
  small: { min: 3, max: 12, start: 8 },
  mid: { min: 13, max: 24, start: 16 },
  large: { min: 25, max: 36, start: 30 },
};

function fieldsFor(path: CoachPath, current: number): number {
  const band = FIELD_BAND[path];
  return Math.min(band.max, Math.max(band.min, current || band.start));
}

function teamStart(path: CoachPath, current: number): number {
  if (path === "custom") return Math.min(40, Math.max(3, current || 11));
  return TEAM_BAND[path].start;
}

function clampTeams(path: CoachPath, count: number, byTeams: boolean): number {
  const raw = Math.min(40, Math.max(3, count || 3));
  if (!byTeams || path === "custom") return raw;
  return Math.min(TEAM_BAND[path].max, Math.max(TEAM_BAND[path].min, raw));
}

function fieldsThatHold(
  teamCount: number,
  dayCount: number,
  format: EventFormat,
  rain: boolean,
  advance: AdvanceMode,
  advancePerPool: number,
): number {
  for (let count = 1; count <= 12; count += 1) {
    const input = { teams: teamCount, fields: count, days: dayCount, format, rain, advance, advancePerPool };
    if (bracketClockForFit(input).late || assessCapacity(input).fit) return count;
  }
  return 12;
}

function Info({ text }: { text: string }) {
  const [open, setOpen] = useState(false);
  return (
    <span className="mt-1 block">
      <button
        type="button"
        aria-expanded={open}
        onClick={() => setOpen((value) => !value)}
        className="inline-flex min-h-8 items-center gap-1 text-xs font-bold uppercase text-muted"
      >
        <span className="inline-flex h-5 w-5 items-center justify-center rounded-full border border-line text-[11px]">i</span>
        What this means
      </button>
      {open ? <span className="mt-1 block text-xs text-muted">{text}</span> : null}
    </span>
  );
}

export function CreateCoach({
  busy,
  error,
  onCreate,
  initialStart,
  initialEnd,
  initialName,
  interestCount = 0,
  finish = false,
}: {
  busy: boolean;
  error: string | null;
  initialStart?: string;
  initialEnd?: string;
  initialName?: string;
  interestCount?: number;
  finish?: boolean;
  onCreate: (input: {
    name: string;
    startDate: string;
    endDate: string;
    ageGroup: AgeGroup;
    maxTeams: number;
    dayPlan: DayPlan[];
    poolPlay: boolean;
    rules: BracketRules;
  }) => void;
}) {
  const defaults = useMemo(() => defaultWeekendDates(), []);
  const [step, setStep] = useState<Step>(finish ? "size" : "name");
  const [name, setName] = useState(initialName ?? "");
  const [ageGroup, setAgeGroup] = useState<AgeGroup>("15U");
  const [startDate, setStartDate] = useState(initialStart && initialStart.length === 10 ? initialStart : defaults.startDate);
  const [endDate, setEndDate] = useState(initialEnd && initialEnd.length === 10 ? initialEnd : defaults.endDate);
  const [driver, setDriver] = useState<SizeDriver>("fields");
  const [path, setPath] = useState<CoachPath>("mid");
  const [fields, setFields] = useState(2);
  const [teams, setTeams] = useState(11);
  const [byWindow, setByWindow] = useState(false);
  const [rain, setRain] = useState(false);
  const [advance, setAdvance] = useState<AdvanceMode>("all-reseed");
  const [advancePerPool, setAdvancePerPool] = useState(2);
  const [format, setFormat] = useState<EventFormat>("pool-then-bracket");
  const [formatTouched, setFormatTouched] = useState(false);
  const [localError, setLocalError] = useState<string | null>(null);

  const days = inclusiveDays(startDate, endDate);
  const byTeams = driver === "teams";
  const pool = format === "pool-then-bracket";
  const typedTeams = clampTeams(path, teams, byTeams);
  const fieldCount =
    byTeams && path !== "custom"
      ? fieldsThatHold(typedTeams, days, format, rain, advance, advancePerPool)
      : fieldsFor(path, fields);
  const askedTeams = byTeams || !byWindow ? typedTeams : Math.max(typedTeams, 2);
  const clockInput: CapacityInput = {
    teams: askedTeams,
    fields: fieldCount,
    days: Math.max(1, days),
    format,
    rain,
    advance,
    advancePerPool,
  };
  const clock = byWindow
    ? { bracketLastMustPlay: "16:00", bracketRainDelay: "18:00", late: false }
    : bracketClockForFit(clockInput);
  const report = capacityReport({ ...clockInput, ...clock });
  const maxFit = report.maxTeams;
  const chosen = byTeams || !byWindow ? typedTeams : Math.max(2, maxFit);
  const fitReport = capacityReport({
    ...clockInput,
    teams: chosen,
    ...clock,
  });
  const fits = fitReport.fit;
  const dayPlan = pool ? defaultDayPlan(startDate, endDate) : eachIsoDate(startDate, endDate).map((date) => ({ date, kind: "bracket" as const }));
  const sizeCards = byTeams ? TEAM_PATHS : FIELD_PATHS;
  const teamBand = path === "custom" ? null : TEAM_BAND[path];
  const fieldBand = FIELD_BAND[path];
  const sizeTitle = sizeCards.find((row) => row.id === path)?.title ?? "";

  function nextFromName() {
    if (name.trim().length < 2) {
      setLocalError("Give the tournament a name.");
      return;
    }
    setLocalError(null);
    setStep("dates");
  }

  function nextFromDates() {
    if (days < 1) {
      setLocalError("Pick a first day and a last day.");
      return;
    }
    if (!formatTouched) setFormat(days <= 1 ? "bracket-only" : "pool-then-bracket");
    setLocalError(null);
    setStep("size");
  }

  function pickPath(next: CoachPath) {
    setPath(next);
    if (byTeams) setTeams(teamStart(next, teams));
    else setFields(FIELD_BAND[next].start);
  }

  function chooseDriver(next: SizeDriver) {
    setDriver(next);
    setLocalError(null);
    if (next === "teams") {
      setByWindow(false);
      setTeams(teamStart(path, teams));
    } else {
      setByWindow(true);
      setFields(FIELD_BAND[path].start);
    }
  }

  function review() {
    if (path !== "custom" && !fits) {
      setLocalError(fitReport.reasons[0] ?? "That lineup does not fit this window.");
      return;
    }
    setLocalError(null);
    setStep("confirm");
  }

  function submit(event: FormEvent) {
    event.preventDefault();
    if (step !== "confirm") {
      if (step === "dial") review();
      return;
    }
    if (path !== "custom" && !fits) {
      setLocalError(fitReport.reasons[0] ?? "That lineup does not fit this window.");
      return;
    }
    setLocalError(null);
    const cuts = namedDivisions(chosen);
    const rules: BracketRules = {
      minTeams: 3,
      elimination: "single",
      advance,
      advancePerPool,
      consolation: false,
      homePool: "coin-flip",
      homeBracket: "higher-seed",
      poolTies: true,
      championshipNoTimeLimit: true,
      timeLimitMinutes: 105,
      mercy: true,
      mercyAfter3: 15,
      mercyAfter4: 10,
      mercyAfter5: 8,
      tiebreakers: ["record", "runs-scored", "run-diff", "head-to-head", "runs-allowed", "coin-flip"],
      poolGamesPerTeam: 2,
      softFill: false,
      firstPitch: "08:00",
      slotMinutes: 120,
      lastStart: "20:00",
      lastDayLastStart: clock.late ? "20:00" : "18:00",
      poolFirstPitch: "08:00",
      poolLastMustPlay: "18:00",
      poolRainDelay: "20:00",
      bracketFirstPitch: "08:00",
      bracketLastMustPlay: clock.bracketLastMustPlay,
      bracketRainDelay: clock.bracketRainDelay,
      championshipCollapse: true,
      packStayOnPark: true,
      packFillFields: true,
      packSeed1vsLast: true,
      packDayFilter: true,
      divisions: cuts.length > 0 ? cuts : setDivisionCount(defaultDivisions(chosen), 1, chosen),
      rainDelay: rain,
      eventDays: days >= 3 ? 3 : 2,
      fieldCount,
      coachPath: path,
      dropCutoffDays: 3,
    };
    onCreate({
      name: name.trim(),
      startDate,
      endDate,
      ageGroup,
      maxTeams: chosen,
      dayPlan,
      poolPlay: pool,
      rules,
    });
  }

  const shownError = localError ?? error;

  return (
    <form onSubmit={submit} className="mt-6 space-y-4">
      <p className="text-xs font-bold uppercase tracking-wide text-muted">
        {step === "name" ? "1 · Name" : step === "dates" ? "2 · Dates" : step === "size" ? "3 · Size" : step === "dial" ? "4 · Setup" : "5 · Confirm"}
      </p>

      {finish ? (
        <p className="text-sm text-muted">
          {interestCount === 0
            ? "No teams have said they're interested yet."
            : interestCount === 1
              ? "1 team is interested. Size this close to that."
              : `${interestCount} teams are interested. Size this close to that.`}
        </p>
      ) : null}
      {step === "name" ? (
        <section className="space-y-4 rounded-lg border border-line bg-surface p-4">
          <div className="space-y-1.5">
            <Label htmlFor="coach-name">Tournament name</Label>
            <Input id="coach-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="TWU 15U" maxLength={80} autoComplete="off" />
            <Info text="The name parents and coaches see. A place name is fine." />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="coach-age">Age</Label>
            <select id="coach-age" value={ageGroup} onChange={(e) => setAgeGroup(e.target.value as AgeGroup)} className="h-11 w-full rounded-md border border-line bg-bg px-3 text-sm">
              {AGE_GROUPS.map((group) => (
                <option key={group} value={group}>{group}</option>
              ))}
            </select>
            <Info text="One age per tournament. Another age is a new tournament." />
          </div>
          <Button type="button" size="lg" className="w-full" onClick={nextFromName}>Next</Button>
        </section>
      ) : null}

      {step === "dates" ? (
        <section className="space-y-4 rounded-lg border border-line bg-surface p-4">
          <div className="space-y-1.5">
            <Label htmlFor="coach-start">First day</Label>
            <MondayDateInput
              id="coach-start"
              value={startDate}
              onChange={(next) => {
                const length = Math.max(1, inclusiveDays(startDate, endDate));
                setStartDate(next);
                if (next) setEndDate(addDays(next, length - 1));
              }}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="coach-end">Last day</Label>
            <MondayDateInput id="coach-end" value={endDate} min={startDate} onChange={setEndDate} />
            <Info text="First day is pool. Last day is bracket. That used to mean Saturday and Sunday, but the days can be anything — Wednesday is fine." />
          </div>
          <p className="text-sm font-semibold">{days > 0 ? `${days} day${days === 1 ? "" : "s"}` : "Pick both dates"} · through {addDays(endDate, 0)}</p>
          <div className="flex gap-2">
            <Button type="button" variant="outline" className="flex-1" onClick={() => setStep("name")}>Back</Button>
            <Button type="button" className="flex-1" onClick={nextFromDates}>Next</Button>
          </div>
        </section>
      ) : null}

      {step === "size" ? (
        <section className="space-y-4 rounded-lg border border-line bg-surface p-4">
          <div className="grid grid-cols-2 gap-2">
            <button type="button" aria-pressed={driver === "fields"} onClick={() => chooseDriver("fields")} className={`min-h-11 rounded-md border px-2 text-sm font-bold ${driver === "fields" ? "border-primary bg-surface" : "border-line"}`}>By fields</button>
            <button type="button" aria-pressed={driver === "teams"} onClick={() => chooseDriver("teams")} className={`min-h-11 rounded-md border px-2 text-sm font-bold ${driver === "teams" ? "border-primary bg-surface" : "border-line"}`}>By # of teams</button>
          </div>
          <Info text={byTeams
            ? "These cards are team counts only. Format is the control under them."
            : "These cards are field counts only. Format is the control under them."} />
          <div className="grid grid-cols-2 gap-2">
            {sizeCards.map((row) => (
              <button key={row.id} type="button" aria-pressed={path === row.id} onClick={() => pickPath(row.id)} className={`min-h-16 rounded-md border px-3 py-2 text-left ${path === row.id ? "border-primary bg-surface" : "border-line"}`}>
                <span className="block text-sm font-bold">{row.title}</span>
                <span className="mt-1 block text-xs text-muted">{row.hint}</span>
              </button>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button type="button" aria-pressed={format === "bracket-only"} onClick={() => { setFormat("bracket-only"); setFormatTouched(true); }} className={`min-h-11 rounded-md border px-2 text-sm font-bold ${format === "bracket-only" ? "border-primary bg-surface" : "border-line"}`}>Bracket only</button>
            <button type="button" aria-pressed={format === "pool-then-bracket"} onClick={() => { setFormat("pool-then-bracket"); setFormatTouched(true); }} className={`min-h-11 rounded-md border px-2 text-sm font-bold ${format === "pool-then-bracket" ? "border-primary bg-surface" : "border-line"}`}>Pool, then bracket</button>
          </div>
          <Info text="One day starts as bracket only. Two or more days start as pool, then bracket. You can switch it. Size does not pick the format." />
          <div className="flex gap-2">
            {finish ? null : (
              <Button type="button" variant="outline" className="flex-1" onClick={() => setStep("dates")}>Back</Button>
            )}
            <Button type="button" className="flex-1" onClick={() => setStep("dial")}>Next</Button>
          </div>
        </section>
      ) : null}

      {step === "dial" ? (
        <section className="space-y-4 rounded-lg border border-line bg-surface p-4">
          <p className="font-display text-2xl font-bold uppercase">{sizeTitle}</p>
          {byTeams && path !== "custom" ? (
            <div className="space-y-1.5">
              <Label htmlFor="coach-teams">Teams ({teamBand ? `${teamBand.min}–${teamBand.max}` : "3–40"})</Label>
              <Input id="coach-teams" inputMode="numeric" value={String(typedTeams)} onChange={(e) => setTeams(clampTeams(path, Number.parseInt(e.target.value, 10) || typedTeams, true))} />
              <p className="text-sm font-semibold">This window holds {maxFit} teams.</p>
              <Info text={path === "small"
                ? "Field count is whatever these teams need. Format is already set."
                : "Field count is the smallest number that holds these teams. Format is already set."} />
            </div>
          ) : path !== "small" ? (
            <div className="space-y-1.5">
              <Label>Fields ({fieldBand.min}–{fieldBand.max})</Label>
              <div className="flex flex-wrap gap-2">
                {Array.from({ length: fieldBand.max - fieldBand.min + 1 }, (_, index) => fieldBand.min + index).map((count) => (
                  <button key={count} type="button" aria-pressed={fieldCount === count} onClick={() => setFields(count)} className={`min-h-11 min-w-11 rounded-md border px-3 text-sm font-bold ${fieldCount === count ? "border-primary bg-surface" : "border-line"}`}>{count}</button>
                ))}
              </div>
              <Info text="Pick a diamond count in this size. Games stay on one park for the day." />
            </div>
          ) : (
            <p className="text-sm text-muted">1 field. No pool games and no pool sheet.</p>
          )}

          {byTeams && path !== "custom" ? null : (
          <>
          <div className="grid grid-cols-2 gap-2">
            <button type="button" aria-pressed={!byWindow} onClick={() => setByWindow(false)} className={`min-h-11 rounded-md border text-sm font-bold ${!byWindow ? "border-primary bg-surface" : "border-line"}`}>By # of teams</button>
            <button type="button" aria-pressed={byWindow} onClick={() => setByWindow(true)} className={`min-h-11 rounded-md border text-sm font-bold ${byWindow ? "border-primary bg-surface" : "border-line"}`}>By schedule window</button>
          </div>
          <Info text="The window uses a 120-minute start, pool must-play through 6:00, and bracket must-play through 4:00. Rain holds 8:00 pool and 6:00 bracket." />

          {byWindow ? (
            <p className="text-sm font-semibold">This window holds {maxFit} teams.</p>
          ) : (
            <div className="space-y-1.5">
              <Label htmlFor="coach-teams">Teams</Label>
              <Input id="coach-teams" inputMode="numeric" value={String(teams)} onChange={(e) => setTeams(Number.parseInt(e.target.value, 10) || teams)} />
            </div>
          )}
          </>
          )}

          {format === "pool-then-bracket" ? (
            <div className="space-y-2">
              <Label htmlFor="coach-advance">Who goes to the bracket</Label>
              <select id="coach-advance" value={advance} onChange={(e) => setAdvance(e.target.value as AdvanceMode)} className="h-11 w-full rounded-md border border-line bg-bg px-3 text-sm">
                <option value="all-reseed">All teams, reseeded</option>
                <option value="top-per-pool">Top from each pool</option>
              </select>
              <Info text="All-reseed uses every team in the bracket, so it takes more games. Top from each pool only advances a few from each pool, so more teams can fit the same window." />
              {advance === "top-per-pool" ? (
                <div className="space-y-1.5">
                  <Label htmlFor="coach-per">Advance per pool</Label>
                  <Input id="coach-per" inputMode="numeric" value={String(advancePerPool)} onChange={(e) => setAdvancePerPool(Math.min(4, Math.max(1, Number.parseInt(e.target.value, 10) || 2)))} />
                </div>
              ) : null}
            </div>
          ) : null}

          <button type="button" aria-pressed={rain} onClick={() => setRain((value) => !value)} className="flex min-h-12 w-full items-center justify-between rounded-md border border-line px-3 text-left">
            <span>
              <span className="block text-sm font-semibold">Rain buffer</span>
              <span className="block text-xs text-muted">Leave the last start of each day open.</span>
            </span>
            <span className="text-xs font-bold uppercase">{rain ? "On" : "Off"}</span>
          </button>
          <Info text="On holds the rain start (8:00 pool, 6:00 bracket). Planned games do not use that start." />

          <p className={`text-sm font-semibold ${fits || path === "custom" ? "" : "text-warn"}`}>
            Max {maxFit} teams · {chosen} chosen · {fitReport.poolGames} pool games · {fitReport.bracketGames} bracket games
            {path === "custom" && !fits ? " · warning only, you can still save" : fits ? " · fits" : " · does not fit"}
          </p>
          {clock.late ? (
            <p className="text-xs text-muted">The bracket day can start at 6:00. 8:00 stays open for rain.</p>
          ) : null}
          <p className="text-xs text-muted">
            {fitReport.divisions.length <= 1
              ? `One division covers all ${chosen} teams.`
              : `Knockout splits into ${fitReport.divisions.join(" + ")} so no bracket is over 12.`}
            {" "}You can rename cuts later in Rules. Open slots stay TBD until a team is approved.
            {path === "custom" ? " Custom does not fill games. You place them." : ""}
          </p>

          {shownError ? <p className="rounded-md bg-warn-bg px-3 py-2 text-sm" role="alert">{shownError}</p> : null}
          <div className="flex gap-2">
            <Button type="button" variant="outline" className="flex-1" onClick={() => setStep("size")}>Back</Button>
            <Button type="button" className="flex-1" disabled={busy} onClick={review}>Review</Button>
          </div>
        </section>
      ) : null}

      {step === "confirm" ? (
        <section className="space-y-4 rounded-lg border border-line bg-surface p-4" aria-label="Confirm tournament">
          <p className="text-xs font-bold uppercase tracking-wide text-muted">
            {sizeTitle}
            {" · "}
            {pool ? "Pool, then bracket" : "Bracket only"}
          </p>
          <p className="font-display text-4xl font-bold uppercase leading-none">
            {byTeams ? `${chosen} team${chosen === 1 ? "" : "s"}` : `${fieldCount} field${fieldCount === 1 ? "" : "s"}`}
          </p>
          <p className="text-sm font-semibold">
            {byTeams
              ? `Uses ${fieldCount} field${fieldCount === 1 ? "" : "s"}.`
              : byWindow
                ? `This window holds ${chosen} teams.`
                : `${chosen} team${chosen === 1 ? "" : "s"} on these fields.`}
          </p>
          <dl className="space-y-2 border-t border-line pt-3 text-sm">
            <div className="flex justify-between gap-3">
              <dt className="text-muted">Name</dt>
              <dd className="text-right font-semibold">{name.trim()}</dd>
            </div>
            <div className="flex justify-between gap-3">
              <dt className="text-muted">Age</dt>
              <dd className="font-semibold">{ageGroup}</dd>
            </div>
            <div className="flex justify-between gap-3">
              <dt className="text-muted">Dates</dt>
              <dd className="text-right font-semibold">{days} day{days === 1 ? "" : "s"} · {startDate} to {endDate}</dd>
            </div>
            <div className="flex justify-between gap-3">
              <dt className="text-muted">Rain buffer</dt>
              <dd className="font-semibold">{clock.late ? "8:00 on the bracket day" : rain ? "On" : "Off"}</dd>
            </div>
          </dl>
          <p className="text-xs text-muted">
            {fitReport.divisions.length <= 1
              ? "One division."
              : `Knockout splits ${fitReport.divisions.join(" + ")}.`}
            {path === "custom" && !fits ? " Custom does not fit this window. You can still create it." : ""}
          </p>
          {shownError ? <p className="rounded-md bg-warn-bg px-3 py-2 text-sm" role="alert">{shownError}</p> : null}
          <div className="flex gap-2">
            <Button type="button" variant="outline" className="flex-1" onClick={() => setStep("dial")}>Back</Button>
            <Button type="submit" className="flex-1" disabled={busy}>{busy ? "Saving…" : "Create"}</Button>
          </div>
        </section>
      ) : null}

      {step !== "dial" && step !== "confirm" && shownError ? <p className="rounded-md bg-warn-bg px-3 py-2 text-sm" role="alert">{shownError}</p> : null}
    </form>
  );
}
