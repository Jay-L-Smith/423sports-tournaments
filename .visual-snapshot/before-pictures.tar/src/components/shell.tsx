import { useQuery } from "@tanstack/react-query";
import { Link, useRouterState } from "@tanstack/react-router";
import { Bell, House, Library, UserRound, X } from "lucide-react";
import { useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { BrandMark } from "@/components/brand";
import { useAppSession } from "@/components/session-gate";
import { UserButton } from "@/lib/auth/gates";
import { listNotifications, listPendingRequests, listPendingTeams } from "@/lib/pbi/api";
import { ROLE_COPY, type Role } from "@/lib/pbi/roles";
import { cn } from "@/lib/utils";

function useNavBadge() {
  const { user, profile } = useAppSession();
  const notifQuery = useQuery({
    queryKey: ["notifications", user?.id],
    queryFn: () => listNotifications(),
    enabled: Boolean(user && profile),
  });
  const pendingQuery = useQuery({
    queryKey: ["pending-requests"],
    queryFn: () => listPendingRequests(),
    enabled: Boolean(profile?.homeRole === "admin"),
  });
  const pendingTeamsQuery = useQuery({
    queryKey: ["pending-teams"],
    queryFn: () => listPendingTeams(),
    enabled: Boolean(profile?.homeRole === "admin"),
  });
  const unread = (notifQuery.data ?? []).filter((n) => !n.read).length;
  const pending =
    profile?.homeRole === "admin"
      ? (pendingQuery.data?.length ?? 0) + (pendingTeamsQuery.data?.length ?? 0)
      : 0;
  return unread + pending;
}

export function AppShell({
  homeRole,
  pendingLabel,
  wide = false,
  children,
}: {
  homeRole: Role;
  pendingLabel?: string | null;
  wide?: boolean;
  children: ReactNode;
}) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const badge = useNavBadge();
  const { user, profile } = useAppSession();
  const [accountOpen, setAccountOpen] = useState(false);
  const items = [
    { to: "/", label: "Home", icon: House, match: (p: string) => p === "/" },
    {
      to: "/notifications",
      label: "Notifications",
      icon: Bell,
      match: (p: string) => p.startsWith("/notifications"),
      badge,
    },
    ...(homeRole === "admin"
      ? [
          {
            to: "/resources",
            label: "Resources",
            icon: Library,
            match: (p: string) => p.startsWith("/resources"),
          },
        ]
      : []),
  ] as const;

  return (
    <div className={cn("mx-auto flex min-h-dvh flex-col bg-white text-fg", wide ? "max-w-none" : "max-w-lg")}>
      <header className="sticky top-0 z-10 bg-[#1c1c1c] px-3 py-2.5 text-white">
        <div className="flex items-center gap-3">
          <BrandMark className="h-14 w-auto" />
          <div className="ml-auto flex shrink-0 items-center gap-2">
            <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-white/80">
              {pendingLabel ?? ROLE_COPY[homeRole].label}
            </p>
            <button
              type="button"
              aria-label="Account"
              aria-expanded={accountOpen}
              onClick={() => setAccountOpen(true)}
              className={cn(
                "grid h-8 w-8 place-items-center rounded-full",
                accountOpen ? "bg-white text-[#1c1c1c]" : "text-white hover:bg-white/10",
              )}
            >
              <UserRound className="h-5 w-5" strokeWidth={2.25} />
            </button>
          </div>
        </div>
      </header>
      <main className={cn("flex-1 bg-white px-4 py-5 text-[#222]", wide ? "pb-24 landscape:pb-3" : "pb-24")}>{children}</main>
      <nav
        className={cn(
          "fixed inset-x-0 bottom-0 z-10 border-t border-[#e5e5e5] bg-white",
          wide && "landscape:hidden",
        )}
      >
        <div className={cn("mx-auto grid max-w-lg", items.length === 3 ? "grid-cols-3" : "grid-cols-2")}>
          {items.map((item) => {
            const active = item.match(pathname);
            const Icon = item.icon;
            const count = "badge" in item ? item.badge : 0;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "relative flex min-h-14 flex-col items-center justify-center gap-0.5 text-xs font-semibold",
                  active ? "text-primary" : "text-muted",
                )}
              >
                <Icon className="h-5 w-5" strokeWidth={active ? 2.4 : 2} />
                {item.label}
                {count ? (
                  <span className="absolute right-1/4 top-1 grid h-5 min-w-5 place-items-center rounded-full bg-primary px-1 text-[10px] text-primary-fg">
                    {count > 9 ? "9+" : count}
                  </span>
                ) : null}
              </Link>
            );
          })}
        </div>
      </nav>
      {accountOpen ? <AccountCard onClose={() => setAccountOpen(false)} email={profile?.email || user?.primaryEmail || "—"} role={ROLE_COPY[homeRole].label} /> : null}
    </div>
  );
}

function AccountCard({ onClose, email, role }: { onClose: () => void; email: string; role: string }) {
  if (typeof document === "undefined") return null;
  return createPortal(
    <div className="fixed inset-0 z-[80] flex items-start justify-center bg-scrim p-4 pt-20" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Account"
        className="w-full max-w-sm rounded-lg border border-line bg-bg p-4 text-fg shadow-lg"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="flex items-center justify-between gap-3">
          <h2 className="font-display text-2xl font-bold uppercase">Account</h2>
          <button type="button" aria-label="Close" onClick={onClose} className="grid h-11 w-11 place-items-center rounded-md text-muted">
            <X className="h-5 w-5" aria-hidden />
          </button>
        </div>
        <div className="mt-4 space-y-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-muted">Email</p>
            <p className="mt-1 font-medium">{email}</p>
          </div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-muted">Home</p>
            <p className="mt-1 font-medium">{role}</p>
          </div>
          <div className="border-t border-line pt-4">
            <UserButton />
          </div>
        </div>
      </div>
    </div>,
    document.body,
  );
}
