import assert from "node:assert/strict";
import test from "node:test";
import {
  announcedWeekendName,
  defaultSeasonWindow,
  preferredSeasonYear,
  archiveIsDue,
  archivePromptOn,
  finalizeIsDue,
  finalizeOpensOn,
  seasonClash,
  seasonOverlaps,
  seasonSaturdays,
  softDeadline,
} from "./weekends.ts";

test("season windows seed to the locked dates", () => {
  assert.deepEqual(defaultSeasonWindow("spring", 2027), {
    season: "spring",
    year: 2027,
    startDate: "2027-03-01",
    endDate: "2027-05-31",
  });
  assert.deepEqual(defaultSeasonWindow("summer", 2027), {
    season: "summer",
    year: 2027,
    startDate: "2027-06-01",
    endDate: "2027-08-31",
  });
  assert.deepEqual(defaultSeasonWindow("fall", 2026), {
    season: "fall",
    year: 2026,
    startDate: "2026-09-01",
    endDate: "2026-11-15",
  });
});

test("finishing a tournament opens two weeks before it starts", () => {
  assert.equal(finalizeOpensOn("2027-03-06"), "2027-02-20");
  assert.equal(finalizeIsDue("2027-02-19", "2027-03-06"), false);
  assert.equal(finalizeIsDue("2027-02-20", "2027-03-06"), true);
});

test("archive waits two weeks after Fall ends", () => {
  assert.equal(archivePromptOn("2027-11-15"), "2027-11-29");
  assert.equal(archiveIsDue("2027-11-28", "2027-11-15"), false);
  assert.equal(archiveIsDue("2027-11-29", "2027-11-15"), true);
  assert.equal(archivePromptOn("2027-11-20"), "2027-12-04");
  assert.equal(archiveIsDue("2027-12-03", "2027-11-20"), false);
  assert.equal(archiveIsDue("2027-12-04", "2027-11-20"), true);
});

test("a past season opens next year, and nothing opens before 2027", () => {
  assert.equal(preferredSeasonYear("spring", "2026-09-25"), 2027);
  assert.equal(preferredSeasonYear("summer", "2026-09-25"), 2027);
  assert.equal(preferredSeasonYear("fall", "2026-09-25"), 2027);
  assert.equal(preferredSeasonYear("fall", "2026-11-16"), 2027);
  assert.equal(preferredSeasonYear("fall", "2027-11-16"), 2028);
});

test("spring lists every Saturday inside the window", () => {
  const rows = seasonSaturdays("2026-03-01", "2026-05-31");
  assert.equal(rows[0]?.startDate, "2026-03-07");
  assert.equal(rows[0]?.endDate, "2026-03-08");
  assert.equal(rows.at(-1)?.startDate, "2026-05-30");
  assert.ok(rows.every((row) => row.startDate >= "2026-03-01" && row.startDate <= "2026-05-31"));
});

test("announced names drop the year", () => {
  assert.equal(announcedWeekendName("2027-04-11", "2027-04-12"), "Apr 11–12");
});

test("soft deadline is 30 days before the first weekend, or the season start", () => {
  assert.equal(softDeadline("2027-03-01", "2027-04-11"), "2027-03-12");
  assert.equal(softDeadline("2027-03-01", null), "2027-01-30");
});

test("overlapping seasons warn and a gap does not", () => {
  const spring = { ...defaultSeasonWindow("spring", 2027), endDate: "2027-06-03" };
  const summer = defaultSeasonWindow("summer", 2027);
  const fall = defaultSeasonWindow("fall", 2027);
  assert.equal(seasonClash(spring, summer), "Spring and Summer overlap on Jun 1–Jun 3.");
  assert.equal(seasonClash(defaultSeasonWindow("spring", 2027), summer), null);
  assert.deepEqual(seasonOverlaps(spring, [summer, fall]), ["Spring and Summer overlap on Jun 1–Jun 3."]);
});
