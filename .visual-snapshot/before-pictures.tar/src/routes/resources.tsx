import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, Navigate } from "@tanstack/react-router";
import { X } from "lucide-react";
import { useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { ParkOptions, parkSummary } from "@/components/park-options";
import { SessionSkeleton, useAppSession } from "@/components/session-gate";
import { AppShell } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { listCoaches, listDirectory, listKnownParks, updateKnownPark, type DirectoryCoach, type KnownPark } from "@/lib/pbi/api";
import { ROLE_COPY } from "@/lib/pbi/roles";
import { parseLocationInput, type ParkFlags } from "@/lib/pbi/weekends";

export const Route = createFileRoute("/resources")({
  component: ResourcesPage,
});

function flagsFrom(park: KnownPark): ParkFlags {
  return {
    chairs: park.chairs,
    canopies: park.canopies,
    concessions: park.concessions,
    restrooms: park.restrooms,
    lights: park.lights,
    bleachers: park.bleachers,
    entranceFee: park.entranceFee,
    entrancePrice: park.entrancePrice,
    ageDiscount: park.ageDiscount,
    discountAges: park.discountAges,
    discountPrice: park.discountPrice,
  };
}

function ResourcesPage() {
  const { user, isPending, profile } = useAppSession();
  const queryClient = useQueryClient();
  const parksQuery = useQuery({
    queryKey: ["known-parks"],
    queryFn: () => listKnownParks(),
    enabled: Boolean(profile?.homeRole === "admin"),
  });
  const coachesQuery = useQuery({
    queryKey: ["coaches"],
    queryFn: () => listCoaches(),
    enabled: Boolean(profile?.homeRole === "admin"),
  });
  const usersQuery = useQuery({
    queryKey: ["directory"],
    queryFn: () => listDirectory(),
    enabled: Boolean(profile?.homeRole === "admin"),
  });
  const [editingId, setEditingId] = useState<number | null>(null);
  const [open, setOpen] = useState<"coaches" | "staff" | "admins" | "fields" | null>(null);

  if (isPending) return <SessionSkeleton />;
  if (!user) return <RedirectToSignIn />;
  if (!profile || profile.homeRole !== "admin") return <Navigate to="/" />;

  const parks = parksQuery.data ?? [];
  const coaches = coachesQuery.data ?? [];
  const admins = (usersQuery.data ?? []).filter((person) => person.homeRole === "admin");

  return (
    <AppShell homeRole={profile.homeRole}>
      <h1 className="font-display text-4xl font-bold uppercase">Resources</h1>
      <div className="mt-6 grid grid-cols-2 gap-2">
        <ResourceButton label="Coaches" onClick={() => setOpen("coaches")} />
        <ResourceButton label="Staff" onClick={() => setOpen("staff")} />
        <ResourceButton label="Administrators" onClick={() => setOpen("admins")} />
        <ResourceButton label="Fields" onClick={() => setOpen("fields")} />
      </div>
      {open ? (
        <ResourceSheet title={sheetTitle(open)} onClose={() => { setOpen(null); setEditingId(null); }}>
          {open === "coaches" ? (
            coachesQuery.isPending ? (
              <p className="text-sm text-muted">Loading coaches…</p>
            ) : coaches.length === 0 ? (
              <p className="text-sm text-muted">No coaches yet.</p>
            ) : (
              <div className="space-y-3">
                {coaches.map((coach) => (
                  <CoachCard key={coach.userId} coach={coach} />
                ))}
              </div>
            )
          ) : null}
          {open === "staff" ? <p className="text-sm text-muted">No staff saved yet.</p> : null}
          {open === "admins" ? (
            usersQuery.isPending ? (
              <p className="text-sm text-muted">Loading administrators…</p>
            ) : admins.length === 0 ? (
              <p className="text-sm text-muted">No administrators yet.</p>
            ) : (
              <ul className="divide-y divide-line overflow-hidden rounded-lg border border-line bg-surface">
                {admins.map((person) => (
                  <li key={person.userId} className="px-4 py-3">
                    <p className="truncate font-medium">{person.email}</p>
                    <p className="text-xs uppercase tracking-wide text-muted">{ROLE_COPY[person.homeRole].label}</p>
                  </li>
                ))}
              </ul>
            )
          ) : null}
          {open === "fields" ? (
            parksQuery.isPending ? (
              <p className="text-sm text-muted">Loading fields…</p>
            ) : parks.length === 0 ? (
              <p className="text-sm text-muted">No fields saved yet. Add one on a tournament and it shows up here.</p>
            ) : (
              <div className="space-y-3">
                {parks.map((park) => (
                  <ParkCard
                    key={park.id}
                    park={park}
                    editing={editingId === park.id}
                    onEdit={() => setEditingId(park.id)}
                    onCancel={() => setEditingId(null)}
                    onSaved={(next) => {
                      queryClient.setQueryData<KnownPark[]>(["known-parks"], (current) =>
                        (current ?? []).map((row) => (row.id === next.id ? next : row)),
                      );
                      setEditingId(null);
                    }}
                  />
                ))}
              </div>
            )
          ) : null}
        </ResourceSheet>
      ) : null}
    </AppShell>
  );
}

function sheetTitle(open: "coaches" | "staff" | "admins" | "fields") {
  if (open === "coaches") return "Coaches";
  if (open === "staff") return "Staff";
  if (open === "admins") return "Administrators";
  return "Fields";
}

function ResourceButton({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex min-h-24 items-center justify-center rounded-lg border border-line bg-surface px-3 text-center font-display text-xl font-bold uppercase leading-none"
    >
      {label}
    </button>
  );
}

function ResourceSheet({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  if (typeof document === "undefined") return null;
  return createPortal(
    <div className="fixed inset-0 z-[80] flex items-end justify-center bg-scrim sm:items-center" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="max-h-[85dvh] w-full max-w-lg overflow-y-auto rounded-t-lg border border-line bg-bg p-4 text-fg shadow-lg sm:rounded-lg"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="flex items-center justify-between gap-3">
          <h2 className="font-display text-3xl font-bold uppercase">{title}</h2>
          <button type="button" aria-label="Close" onClick={onClose} className="grid h-11 w-11 place-items-center rounded-md text-muted">
            <X className="h-5 w-5" aria-hidden />
          </button>
        </div>
        <div className="mt-4">{children}</div>
      </div>
    </div>,
    document.body,
  );
}

function CoachCard({ coach }: { coach: DirectoryCoach }) {
  const title = coach.teamName || coach.email;
  return (
    <article className="rounded-lg border border-line bg-surface px-4 py-4">
      <div className="flex items-start justify-between gap-3">
        <h3 className="font-display text-2xl font-bold uppercase leading-none">{title}</h3>
        <span className="shrink-0 text-xs font-bold uppercase tracking-wide text-muted">
          {coach.status === "approved" ? "Approved" : "Waiting"}
        </span>
      </div>
      {coach.teamName ? <p className="mt-2 text-sm">{coach.email}</p> : null}
      <p className="mt-2 text-sm text-muted">
        {coach.teams.length === 0
          ? "No teams signed up yet."
          : coach.teams.length === 1
            ? coach.teams[0]
            : coach.teams.join(", ")}
      </p>
    </article>
  );
}

function ParkCard({
  park,
  editing,
  onEdit,
  onCancel,
  onSaved,
}: {
  park: KnownPark;
  editing: boolean;
  onEdit: () => void;
  onCancel: () => void;
  onSaved: (park: KnownPark) => void;
}) {
  const [name, setName] = useState(park.name);
  const [address, setAddress] = useState(park.address);
  const [flags, setFlags] = useState<ParkFlags>(() => flagsFrom(park));
  const [formError, setFormError] = useState<string | null>(null);
  const saveMut = useMutation({
    mutationFn: () => updateKnownPark({ data: { id: park.id, name, address, ...flags } }),
    onSuccess: (next) => {
      setFormError(null);
      onSaved(next);
    },
  });
  const summary = parkSummary(park);
  const errorText =
    formError ??
    (saveMut.error instanceof Error ? saveMut.error.message : saveMut.error ? "Could not save that park." : null);

  function save() {
    setFormError(null);
    try {
      parseLocationInput({ weekendId: 1, name, address });
      saveMut.mutate();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : "Check the park and try again.");
    }
  }

  return (
    <article className="rounded-lg border border-line bg-surface px-4 py-4">
      {editing ? (
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor={`resource-name-${park.id}`}>Name</Label>
            <Input id={`resource-name-${park.id}`} value={name} onChange={(event) => setName(event.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor={`resource-address-${park.id}`}>Address</Label>
            <Input
              id={`resource-address-${park.id}`}
              value={address}
              onChange={(event) => setAddress(event.target.value)}
            />
          </div>
          <ParkOptions idPrefix={`resource-${park.id}`} flags={flags} onChange={setFlags} />
          <p className="text-xs text-muted">This updates the saved park. Tournaments already using it stay as they are.</p>
          {errorText ? (
            <p className="rounded-md bg-warn-bg px-3 py-2 text-sm" role="alert">
              {errorText}
            </p>
          ) : null}
          <Button type="button" className="w-full" disabled={saveMut.isPending} onClick={save}>
            {saveMut.isPending ? "Saving…" : "Save park"}
          </Button>
          <Button type="button" variant="ghost" className="w-full text-muted" onClick={onCancel}>
            Cancel
          </Button>
        </div>
      ) : (
        <>
          <h2 className="font-display text-2xl font-bold uppercase leading-none">{park.name}</h2>
          <p className="mt-2 text-sm">{park.address}</p>
          {summary ? <p className="mt-2 text-xs font-semibold uppercase tracking-wide text-muted">{summary}</p> : null}
          <Button
            type="button"
            variant="outline"
            className="mt-3"
            onClick={() => {
              setName(park.name);
              setAddress(park.address);
              setFlags(flagsFrom(park));
              setFormError(null);
              onEdit();
            }}
          >
            Edit
          </Button>
        </>
      )}
    </article>
  );
}
