import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { SessionSkeleton, useAppSession } from "@/components/session-gate";
import { AppShell } from "@/components/shell";
import { ArchiveYearPrompt } from "@/components/homes";
import { Button } from "@/components/ui/button";
import { MondayDateInput } from "@/components/monday-date-input";
import { Input } from "@/components/ui/input";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { announceTournament, getSeasonPlan, listWeekends, saveSeasonSchedule, type SeasonPlan, type Weekend } from "@/lib/pbi/api";
import {
  addDays,
  announcedWeekendName,
  formatAgeGroups,
  formatSeasonSpan,
  formatWeekendRange,
  isSeason,
  seasonOverlaps,
  softDeadline,
  softDeadlineCopy,
  isoDateFromLocal,
} from "@/lib/pbi/weekends";

export const Route = createFileRoute("/seasons/$season")({
  validateSearch: (search: Record<string, unknown>): { year?: number } => {
    const year = Number(search.year);
    if (Number.isInteger(year) && year > 2000 && year < 2100) return { year };
    return {};
  },
  component: SeasonPage,
});

const WEEKDAYS = ["M", "T", "W", "T", "F", "S", "S"];

function SeasonPage() {
  const { season: raw } = Route.useParams();
  const { year } = Route.useSearch();
  const { user, isPending, profile } = useAppSession();
  const season = isSeason(raw) ? raw : null;
  const planQuery = useQuery({
    queryKey: ["season-plan", season, year ?? "open"],
    queryFn: () => getSeasonPlan({ data: { season, year } }),
    enabled: Boolean(user && profile?.homeRole === "admin" && season),
  });
  const weekendsQuery = useQuery({
    queryKey: ["weekends"],
    queryFn: () => listWeekends(),
    enabled: Boolean(user && profile?.homeRole === "admin" && season),
  });

  if (isPending) return <SessionSkeleton />;
  if (!user) return <RedirectToSignIn />;
  if (!profile || profile.homeRole !== "admin") return <Navigate to="/" />;
  if (!season) return <Navigate to="/" />;
  if (planQuery.data && year !== planQuery.data.year) {
    return <Navigate to="/seasons/$season" params={{ season }} search={{ year: planQuery.data.year }} replace />;
  }

  return (
    <AppShell homeRole="admin">
      <Link to="/" className="text-sm font-semibold text-muted">
        ← Admin home
      </Link>
      {planQuery.isPending ? (
        <p className="mt-6 text-sm text-muted">Loading the calendar…</p>
      ) : planQuery.data ? (
        <SeasonPlanner
          key={`${planQuery.data.season}-${planQuery.data.year}-${planQuery.data.startDate}-${planQuery.data.endDate}-${planQuery.data.announcedCount}`}
          plan={planQuery.data}
          weekends={weekendsQuery.data ?? []}
        />
      ) : (
        <p className="mt-4 rounded-md bg-warn-bg px-3 py-2 text-sm" role="alert">
          {planQuery.error instanceof Error ? planQuery.error.message : "Could not open that season."}
        </p>
      )}
    </AppShell>
  );
}

function inWindow(weekend: Weekend, start: string, end: string) {
  return weekend.startDate <= end && weekend.endDate >= start;
}

function monthsInRange(start: string, end: string): { year: number; month: number }[] {
  if (end < start || start.length < 7 || end.length < 7) return [];
  const ys = Number(start.slice(0, 4));
  const ms = Number(start.slice(5, 7));
  const ye = Number(end.slice(0, 4));
  const me = Number(end.slice(5, 7));
  if (!ys || !ms || !ye || !me) return [];
  const out: { year: number; month: number }[] = [];
  let y = ys;
  let m = ms;
  let guard = 0;
  while ((y < ye || (y === ye && m <= me)) && guard < 18) {
    out.push({ year: y, month: m });
    m += 1;
    if (m > 12) {
      m = 1;
      y += 1;
    }
    guard += 1;
  }
  return out;
}

function monthCells(year: number, month: number): { iso: string; inMonth: boolean }[] {
  const first = new Date(year, month - 1, 1);
  const pad = (first.getDay() + 6) % 7;
  const count = new Date(year, month, 0).getDate();
  const cells: { iso: string; inMonth: boolean }[] = [];
  for (let i = 0; i < pad; i += 1) {
    const dt = new Date(year, month - 1, 1 - (pad - i));
    cells.push({ iso: isoDateFromLocal(dt), inMonth: false });
  }
  for (let day = 1; day <= count; day += 1) {
    const iso = `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
    cells.push({ iso, inMonth: true });
  }
  while (cells.length < 42) {
    cells.push({ iso: addDays(cells[cells.length - 1].iso, 1), inMonth: false });
  }
  return cells;
}

function dayNumber(iso: string) {
  return Number(iso.slice(8, 10));
}

function dayTitle(iso: string) {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y || 2000, (m || 1) - 1, d || 1).toLocaleDateString("en-US", {
    weekday: "long",
    month: "short",
    day: "numeric",
  });
}

function monthKeyOf(month: { year: number; month: number }) {
  return `${month.year}-${String(month.month).padStart(2, "0")}`;
}

function monthTitle(year: number, month: number) {
  return new Date(year, month - 1, 1).toLocaleDateString("en-US", { month: "long", year: "numeric" });
}

function spanFromDay(iso: string): { startDate: string; endDate: string } {
  return { startDate: iso, endDate: addDays(iso, 1) };
}

function covers(weekend: Weekend, iso: string) {
  return iso >= weekend.startDate && iso <= weekend.endDate;
}

function dayTone(iso: string, weekends: Weekend[], today: string) {
  const covering = weekends.filter((weekend) => covers(weekend, iso));
  if (covering.length === 0) return null;
  if (iso < today) return "past";
  if (covering.some((weekend) => weekend.lifecycle !== "announced")) return "final";
  return "posted";
}

function SeasonPlanner({ plan, weekends }: { plan: SeasonPlan; weekends: Weekend[] }) {
  const queryClient = useQueryClient();
  const today = isoDateFromLocal(new Date());
  const [startDate, setStartDate] = useState(plan.startDate);
  const [endDate, setEndDate] = useState(plan.endDate);
  const [note, setNote] = useState<string | null>(null);
  const [editing, setEditing] = useState(false);
  const [picks, setPicks] = useState<Record<string, string>>({});
  const [pickedTouched, setPickedTouched] = useState(false);
  const [monthKey, setMonthKey] = useState(() => (today >= plan.startDate && today <= plan.endDate ? today : plan.startDate).slice(0, 7));
  const [cardName, setCardName] = useState("");
  const [cardStart, setCardStart] = useState("");
  const [cardEnd, setCardEnd] = useState("");

  const focus = { season: plan.season, year: plan.year, startDate, endDate };
  const overlaps = endDate >= startDate ? seasonOverlaps(focus, plan.others) : [];
  const scheduled = weekends
    .filter((weekend) => inWindow(weekend, startDate, endDate))
    .sort((a, b) => (a.startDate === b.startDate ? a.id - b.id : a.startDate.localeCompare(b.startDate)));
  const first = scheduled[0]?.startDate ?? null;
  const deadline = softDeadline(startDate, first);
  const pastDeadline = today > deadline;
  const months = monthsInRange(startDate, endDate);
  const visible = months.find((month) => monthKeyOf(month) === monthKey) ?? months[0] ?? null;
  const cells = visible ? monthCells(visible.year, visible.month) : [];
  const monthName = visible ? new Date(visible.year, visible.month - 1, 1).toLocaleDateString("en-US", { month: "long" }) : "";
  const monthTournaments = visible
    ? scheduled.filter((weekend) => weekend.startDate.slice(0, 7) <= monthKeyOf(visible) && weekend.endDate.slice(0, 7) >= monthKeyOf(visible))
    : [];
  const picked = visible ? picks[monthKeyOf(visible)] ?? null : null;
  const onDay = picked ? scheduled.filter((weekend) => covers(weekend, picked)) : [];
  const addOnDay = picked ? spanFromDay(picked) : null;

  useEffect(() => {
    if (pickedTouched) return;
    const next = scheduled.find((weekend) => weekend.endDate >= today);
    if (!next) return;
    setMonthKey(next.startDate.slice(0, 7));
  }, [pickedTouched, scheduled, today]);

  useEffect(() => {
    if (!addOnDay) return;
    setCardName(announcedWeekendName(addOnDay.startDate, addOnDay.endDate));
    setCardStart(addOnDay.startDate);
    setCardEnd(addOnDay.endDate);
  }, [picked]);

  const save = useMutation({
    mutationFn: () =>
      saveSeasonSchedule({
        data: {
          season: plan.season,
          year: plan.year,
          startDate,
          endDate,
          notify: false,
        },
      }),
    onSuccess: async (next) => {
      setNote(next.warnings[0] ?? "Season saved.");
      await queryClient.invalidateQueries({ queryKey: ["season-plan"] });
      await queryClient.invalidateQueries({ queryKey: ["season-cards"] });
      await queryClient.invalidateQueries({ queryKey: ["weekends"] });
      await queryClient.invalidateQueries({ queryKey: ["my-schedule"] });
    },
  });

  const announce = useMutation({
    mutationFn: () =>
      announceTournament({
        data: { name: cardName.trim(), startDate: cardStart, endDate: cardEnd, season: plan.season, year: plan.year },
      }),
    onSuccess: async () => {
      clearPicked();
      await queryClient.invalidateQueries({ queryKey: ["weekends"] });
      await queryClient.invalidateQueries({ queryKey: ["season-cards"] });
      await queryClient.invalidateQueries({ queryKey: ["my-schedule"] });
    },
  });

  function clearPicked() {
    if (!visible) return;
    const key = monthKeyOf(visible);
    setPicks((current) => {
      if (!current[key]) return current;
      const next = { ...current };
      delete next[key];
      return next;
    });
  }

  const error = save.error instanceof Error ? save.error.message : null;
  const monthIndex = visible ? months.findIndex((month) => monthKeyOf(month) === monthKeyOf(visible)) : -1;
  const swipe = useRef<{ x: number; y: number } | null>(null);
  const swiped = useRef(false);

  function stepMonth(dir: -1 | 1) {
    const next = months[monthIndex + dir];
    if (!next) return;
    setPickedTouched(true);
    setMonthKey(monthKeyOf(next));
  }

  return (
    <div className="mt-4 space-y-5">
      <h1 className="font-display text-4xl font-bold uppercase leading-none">
        {plan.label} {plan.year}
      </h1>
      <ArchiveYearPrompt rollover={plan.rollover} />
      <button
        type="button"
        onClick={() => setEditing(true)}
        className="text-left text-sm font-medium text-muted underline decoration-line underline-offset-4"
      >
        {formatSeasonSpan(startDate, endDate)}
      </button>

      {overlaps.map((message) => (
        <p key={message} className="rounded-md bg-warn-bg px-3 py-2 text-sm" role="status">
          {message}
        </p>
      ))}
      {pastDeadline ? (
        <p className="rounded-md bg-warn-bg px-3 py-2 text-sm" role="status">
          {softDeadlineCopy(plan.season, deadline)}
        </p>
      ) : null}

      {visible ? (
        <section
          className="space-y-2 touch-pan-y"
          onPointerDown={(event) => {
            if (event.pointerType === "mouse" && event.button !== 0) return;
            swipe.current = { x: event.clientX, y: event.clientY };
          }}
          onPointerUp={(event) => {
            const start = swipe.current;
            swipe.current = null;
            if (!start) return;
            const dx = event.clientX - start.x;
            const dy = event.clientY - start.y;
            if (Math.abs(dx) < 48 || Math.abs(dx) < Math.abs(dy)) return;
            swiped.current = true;
            stepMonth(dx < 0 ? 1 : -1);
          }}
          onPointerCancel={() => {
            swipe.current = null;
          }}
        >
          <div className="flex items-center gap-1">
            <SlideArrow label="Previous month" disabled={monthIndex <= 0} direction="left" onClick={() => stepMonth(-1)} />
            <h2 className="min-w-0 flex-1 text-center font-display text-2xl font-bold uppercase leading-none">
              {monthTitle(visible.year, visible.month)}
            </h2>
            <SlideArrow label="Next month" disabled={monthIndex < 0 || monthIndex >= months.length - 1} direction="right" onClick={() => stepMonth(1)} />
          </div>
          <div className="grid grid-cols-7 gap-1 text-center text-xs font-bold uppercase text-muted">
            {WEEKDAYS.map((label, index) => (
              <span key={`${label}-${index}`}>{label}</span>
            ))}
          </div>
          <div className="grid h-[17.75rem] grid-cols-7 grid-rows-6 gap-1">
            {cells.map((cell) => {
              const inside = cell.inMonth && cell.iso >= startDate && cell.iso <= endDate;
              const tone = cell.inMonth ? dayTone(cell.iso, scheduled, today) : null;
              const isPicked = cell.iso === picked;
              const fill =
                tone === "past"
                  ? "bg-[#d5d5d5] text-[#333]"
                  : tone === "final"
                    ? "bg-pine text-pine-fg"
                    : tone === "posted"
                      ? "bg-[#f5c518] text-[#1c1c1c]"
                      : isPicked
                        ? "bg-surface text-fg"
                        : inside
                          ? "bg-surface text-fg"
                          : "text-muted";
              return (
                <button
                  key={cell.iso}
                  type="button"
                  disabled={!cell.inMonth}
                  aria-hidden={!cell.inMonth}
                  aria-pressed={isPicked}
                  aria-label={cell.inMonth ? dayTitle(cell.iso) : undefined}
                  onClick={() => {
                    if (swiped.current) {
                      swiped.current = false;
                      return;
                    }
                    setPickedTouched(true);
                    const key = cell.iso.slice(0, 7);
                    setMonthKey(key);
                    setPicks((current) => ({ ...current, [key]: cell.iso }));
                  }}
                  className={`flex h-full min-h-11 items-center justify-center rounded-md text-sm font-semibold ${fill} ${
                    !cell.inMonth ? "invisible" : isPicked ? "ring-2 ring-[#1c1c1c]" : ""
                  }`}
                >
                  {dayNumber(cell.iso)}
                </button>
              );
            })}
          </div>
          <ul className="flex flex-wrap gap-x-4 gap-y-1 pt-1 text-xs font-semibold text-muted">
            <li className="flex items-center gap-1.5">
              <span className="h-3 w-3 rounded-sm bg-[#f5c518]" aria-hidden />
              Posted
            </li>
            <li className="flex items-center gap-1.5">
              <span className="h-3 w-3 rounded-sm bg-pine" aria-hidden />
              Finalized
            </li>
            <li className="flex items-center gap-1.5">
              <span className="h-3 w-3 rounded-sm bg-[#d5d5d5]" aria-hidden />
              Past
            </li>
          </ul>
        </section>
      ) : (
        <p className="text-sm text-muted">Pick a start and end that include a month.</p>
      )}

      <section className="space-y-3">
        <h2 className="font-display text-2xl font-bold uppercase">All {monthName} tournaments</h2>
        {monthTournaments.length === 0 ? (
          <p className="rounded-lg border border-dashed border-line bg-surface px-4 py-4 text-sm text-muted">
            Nothing in {monthName} yet.
          </p>
        ) : (
          <ul className="space-y-2">
            {monthTournaments.map((weekend) => (
              <li key={weekend.id}>
                <TournamentCard weekend={weekend} />
              </li>
            ))}
          </ul>
        )}
      </section>

      {editing ? (
        <PullUp title="Edit season" onClose={() => setEditing(false)}>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <label className="space-y-1 text-sm font-semibold">
                Starts
                <MondayDateInput id="season-start" value={startDate} onChange={setStartDate} className="h-11 bg-bg text-sm" />
              </label>
              <label className="space-y-1 text-sm font-semibold">
                Ends
                <MondayDateInput id="season-end" value={endDate} min={startDate} onChange={setEndDate} className="h-11 bg-bg text-sm" />
              </label>
            </div>
            {error ? (
              <p className="rounded-md bg-warn-bg px-3 py-2 text-sm" role="alert">
                {error}
              </p>
            ) : null}
            {note && !error ? <p className="text-sm text-muted">{note}</p> : null}
            {plan.warnings.map((warning) => (
              <p key={warning} className="rounded-md bg-warn-bg px-3 py-2 text-sm" role="status">
                {warning}
              </p>
            ))}
            <Button type="button" className="w-full" disabled={save.isPending || endDate < startDate} onClick={() => save.mutate()}>
              {save.isPending ? "Saving…" : "Save Season"}
            </Button>
          </div>
        </PullUp>
      ) : null}

      {picked && addOnDay ? (
        <PullUp title={dayTitle(picked)} onClose={clearPicked}>
          <div className="space-y-2">
            {onDay.length === 0 ? (
              <p className="text-sm text-muted">Nothing scheduled this day.</p>
            ) : (
              onDay.map((weekend) => (
                <Link
                  key={weekend.id}
                  to="/weekends/$weekendId"
                  params={{ weekendId: String(weekend.id) }}
                  className="flex min-h-11 items-center justify-between gap-2 rounded-md border border-line bg-surface px-3 py-2"
                >
                  <span className="min-w-0">
                    <span className="block truncate text-sm font-semibold">View {weekend.name}</span>
                    <span className="block text-xs text-muted">
                      {weekend.lifecycle === "announced" ? "Not finalized" : formatWeekendRange(weekend.startDate, weekend.endDate)}
                    </span>
                  </span>
                  <ChevronRight className="h-4 w-4 shrink-0 text-muted" aria-hidden />
                </Link>
              ))
            )}
            <div className="space-y-3 border-t border-line pt-3">
              <label className="block space-y-1 text-sm font-semibold">
                Name
                <Input value={cardName} onChange={(event) => setCardName(event.target.value)} maxLength={80} autoComplete="off" />
              </label>
              <div className="grid grid-cols-2 gap-2">
                <label className="block space-y-1 text-sm font-semibold">
                  First day
                  <MondayDateInput value={cardStart} onChange={setCardStart} className="h-11 text-sm" />
                </label>
                <label className="block space-y-1 text-sm font-semibold">
                  Last day
                  <MondayDateInput value={cardEnd} min={cardStart} onChange={setCardEnd} className="h-11 text-sm" />
                </label>
              </div>
              {announce.error instanceof Error ? (
                <p className="rounded-md bg-warn-bg px-3 py-2 text-sm" role="alert">
                  {announce.error.message}
                </p>
              ) : null}
              <Button
                type="button"
                className="w-full"
                disabled={announce.isPending || !cardName.trim() || !cardStart || cardEnd < cardStart}
                onClick={() => announce.mutate()}
              >
                {announce.isPending ? "Saving…" : "Dates verified"}
              </Button>
            </div>
          </div>
        </PullUp>
      ) : null}
    </div>
  );
}

function PullUp({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  if (typeof document === "undefined") return null;
  return createPortal(
    <div className="fixed inset-0 z-[80] flex items-end justify-center bg-scrim p-4 sm:items-center" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="max-h-[85dvh] w-full max-w-md overflow-y-auto rounded-lg border border-line bg-bg p-4 text-fg shadow-lg"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="flex items-center justify-between gap-3">
          <h2 className="font-display text-2xl font-bold uppercase">{title}</h2>
          <Button type="button" variant="ghost" className="px-2 text-muted" onClick={onClose}>
            Close
          </Button>
        </div>
        <div className="mt-4">{children}</div>
      </div>
    </div>,
    document.body,
  );
}

function dateStamp(start: string) {
  const [ys, ms, ds] = start.split("-").map(Number);
  const startDt = new Date(ys || 0, (ms || 1) - 1, ds || 1);
  return {
    month: startDt.toLocaleDateString("en-US", { month: "short" }),
    day: ds ? String(ds) : "—",
  };
}

function interestLine(count: number) {
  if (count === 0) return "Waiting on interest";
  return count === 1 ? "1 team interested" : `${count} teams interested`;
}

function tournamentFacts(weekend: Weekend) {
  if (weekend.lifecycle === "announced") {
    return ["Not finalized", interestLine(weekend.interestCount)];
  }
  const facts: string[] = [];
  if (weekend.ageGroups.length > 0) facts.push(formatAgeGroups(weekend.ageGroups));
  facts.push(weekend.approvedCount === 1 ? "1 team" : `${weekend.approvedCount} teams`);
  if (weekend.rules.fieldCount > 0) {
    facts.push(weekend.rules.fieldCount === 1 ? "1 field" : `${weekend.rules.fieldCount} fields`);
  }
  return facts;
}

function TournamentCard({ weekend }: { weekend: Weekend }) {
  const stamp = dateStamp(weekend.startDate);
  const facts = tournamentFacts(weekend);
  return (
    <Link
      to="/weekends/$weekendId"
      params={{ weekendId: String(weekend.id) }}
      className="flex items-start gap-3 rounded-lg border border-line bg-surface px-3 py-3"
    >
      <span className="grid h-14 w-14 shrink-0 place-items-center rounded-md bg-sheet-surface text-center leading-none">
        <span className="text-xs font-bold uppercase tracking-wide text-muted">{stamp.month}</span>
        <span className="mt-1 font-display text-lg font-bold leading-none tracking-normal">{stamp.day}</span>
      </span>
      <span className="min-w-0 flex-1">
        <span className="block truncate text-base font-semibold leading-tight">{weekend.name}</span>
        <span className="mt-0.5 block text-sm text-muted">{formatWeekendRange(weekend.startDate, weekend.endDate)}</span>
        <span className="mt-1.5 flex flex-wrap gap-1">
          {facts.map((fact) => (
            <span key={fact} className="inline-flex items-center rounded-md bg-sheet-surface px-1.5 py-0.5 text-xs font-semibold text-fg">
              {fact}
            </span>
          ))}
        </span>
      </span>
      <ChevronRight className="mt-1 h-5 w-5 shrink-0 text-muted" aria-hidden />
    </Link>
  );
}

function SlideArrow({
  label,
  disabled,
  direction,
  onClick,
}: {
  label: string;
  disabled: boolean;
  direction: "left" | "right";
  onClick: () => void;
}) {
  const Icon = direction === "left" ? ChevronLeft : ChevronRight;
  return (
    <button
      type="button"
      aria-label={label}
      disabled={disabled}
      onClick={onClick}
      className="grid h-11 w-11 shrink-0 place-items-center rounded-full text-fg disabled:text-muted/40"
    >
      <Icon className="h-6 w-6" aria-hidden />
    </button>
  );
}
