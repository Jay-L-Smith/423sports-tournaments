import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, Navigate, useNavigate, useRouter } from "@tanstack/react-router";
import { CreateCoach } from "@/components/create-coach";
import { SessionSkeleton, useAppSession } from "@/components/session-gate";
import { AppShell } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { createWeekend, finalizeWeekend, listWeekends, type Weekend } from "@/lib/pbi/api";
import { addDays, isSeason, parseWeekendInput } from "@/lib/pbi/weekends";

export const Route = createFileRoute("/weekends/")({
  validateSearch: (search: Record<string, unknown>): { add?: 1; start?: string; season?: "spring" | "summer" | "fall"; year?: number; announce?: number } => {
    const out: { add?: 1; start?: string; season?: "spring" | "summer" | "fall"; year?: number; announce?: number } = {};
    if (search.add === 1 || search.add === "1") out.add = 1;
    if (typeof search.start === "string" && /^\d{4}-\d{2}-\d{2}$/.test(search.start)) out.start = search.start;
    if (isSeason(search.season)) out.season = search.season;
    const year = Number(search.year);
    if (Number.isInteger(year) && year > 2000 && year < 2100) out.year = year;
    const announce = Number(search.announce);
    if (Number.isInteger(announce) && announce > 0) out.announce = announce;
    return out;
  },
  component: WeekendsPage,
});

function WeekendsPage() {
  const { user, isPending, profile } = useAppSession();
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const router = useRouter();
  const { add, start, season, year, announce } = Route.useSearch();
  const adding = add === 1;
  const sourceQuery = useQuery({
    queryKey: ["weekends"],
    queryFn: () => listWeekends(),
    enabled: Boolean(user && adding && announce),
  });
  const source = sourceQuery.data?.find((row) => row.id === announce) ?? null;

  const createMut = useMutation({
    mutationFn: (input: Parameters<typeof parseWeekendInput>[0]) => createWeekend({ data: parseWeekendInput(input) }),
    onSuccess: (created) => {
      queryClient.setQueryData<Weekend[]>(["weekends"], (current) => {
        const nextList = [...(current ?? []).filter((row) => row.id !== created.id), created];
        nextList.sort((a, b) =>
          a.startDate === b.startDate ? a.id - b.id : a.startDate.localeCompare(b.startDate),
        );
        return nextList;
      });
      void queryClient.invalidateQueries({ queryKey: ["weekends"] });
      void navigate({ to: "/weekends/$weekendId", params: { weekendId: String(created.id) } });
    },
  });

  const finishMut = useMutation({
    mutationFn: (input: Parameters<typeof parseWeekendInput>[0]) => {
      if (!announce) throw new Error("Missing tournament.");
      return finalizeWeekend({ data: { weekendId: announce, ...parseWeekendInput(input) } });
    },
    onSuccess: (created) => {
      queryClient.setQueryData<Weekend[]>(["weekends"], (current) => {
        const nextList = [...(current ?? []).filter((row) => row.id !== created.id), created];
        nextList.sort((a, b) => (a.startDate === b.startDate ? a.id - b.id : a.startDate.localeCompare(b.startDate)));
        return nextList;
      });
      void queryClient.invalidateQueries({ queryKey: ["weekends"] });
      void queryClient.invalidateQueries({ queryKey: ["season-cards"] });
      void navigate({ to: "/weekends/$weekendId", params: { weekendId: String(created.id) } });
    },
  });

  if (isPending) return <SessionSkeleton />;
  if (!user) return <RedirectToSignIn />;
  if (!profile) return <Navigate to="/" />;
  if (profile.homeRole !== "admin") return <Navigate to="/" />;
  if (!adding) return <Navigate to="/" />;

  const pendingMut = announce ? finishMut : createMut;
  const errorText = pendingMut.error instanceof Error ? pendingMut.error.message : pendingMut.error ? "Could not save that tournament." : null;
  const finishing = Boolean(announce);

  return (
    <AppShell homeRole={profile.homeRole}>
      <div className="flex items-center justify-between gap-3">
        <h1 className="font-display text-4xl font-bold uppercase">{finishing ? "Finish tournament" : "New tournament"}</h1>
        <Button
          type="button"
          variant="ghost"
          className="px-2 text-muted"
          onClick={() => {
            if (announce) {
              router.history.back();
              return;
            }
            if (season) {
              void navigate({ to: "/seasons/$season", params: { season }, search: year ? { year } : {} });
              return;
            }
            void navigate({ to: "/" });
          }}
        >
          Cancel
        </Button>
      </div>
      {finishing && sourceQuery.isPending ? <p className="mt-6 text-sm text-muted">Loading that tournament…</p> : null}
      {finishing && sourceQuery.isSuccess && (!source || source.lifecycle !== "announced") ? (
        <p className="mt-6 rounded-md bg-warn-bg px-3 py-2 text-sm">That tournament is already built, or it’s gone.</p>
      ) : null}
      {!finishing || (source && source.lifecycle === "announced") ? (
      <CreateCoach
        busy={pendingMut.isPending}
        error={errorText}
        finish={finishing}
        interestCount={source?.interestCount ?? 0}
        initialName={source?.name}
        initialStart={source?.startDate ?? start}
        initialEnd={source?.endDate ?? (start ? addDays(start, 1) : undefined)}
        onCreate={(input) => {
          const payload = {
            name: input.name,
            startDate: input.startDate,
            endDate: input.endDate,
            ageGroups: [input.ageGroup],
            maxTeams: input.maxTeams,
            poolPlay: input.poolPlay,
            dayPlan: input.dayPlan,
            rules: input.rules,
          };
          if (finishing) finishMut.mutate(payload);
          else createMut.mutate(payload);
        }}
      />
      ) : null}
    </AppShell>
  );
}
