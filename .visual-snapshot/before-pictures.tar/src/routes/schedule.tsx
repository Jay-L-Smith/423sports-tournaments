import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { useState } from "react";
import { SessionSkeleton, useAppSession } from "@/components/session-gate";
import { AppShell } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { listMyInterest, listSchedule, showInterest } from "@/lib/pbi/api";
import { formatWeekendRange } from "@/lib/pbi/weekends";

export const Route = createFileRoute("/schedule")({
  component: SchedulePage,
});

function SchedulePage() {
  const { user, isPending, profile } = useAppSession();
  const scheduleQuery = useQuery({
    queryKey: ["my-schedule"],
    queryFn: () => listSchedule(),
    enabled: Boolean(user && profile),
  });
  const interestQuery = useQuery({
    queryKey: ["my-interest"],
    queryFn: () => listMyInterest(),
    enabled: Boolean(user && profile?.homeRole === "coach"),
  });

  if (isPending) return <SessionSkeleton />;
  if (!user) return <RedirectToSignIn />;
  if (!profile) return <Navigate to="/" />;

  const items = scheduleQuery.data ?? [];
  const announced = items.filter((item) => item.weekend.lifecycle === "announced");
  const playing = items.filter((item) => item.weekend.lifecycle !== "announced");

  return (
    <AppShell homeRole={profile.homeRole}>
      <h1 className="font-display text-4xl font-bold uppercase">Schedule</h1>
      <p className="mt-2 text-sm text-muted">Dates the league is planning, then the games that are on the clock.</p>

      {scheduleQuery.isPending ? (
        <p className="mt-6 text-sm text-muted">Loading games…</p>
      ) : announced.length === 0 && playing.length === 0 ? (
        <p className="mt-6 rounded-lg border border-line bg-surface px-4 py-4 text-sm text-muted">
          No season dates yet. Brackets show up closer to the weekend.
        </p>
      ) : (
        <div className="mt-6 space-y-8">
          {announced.length > 0 ? (
            <section className="space-y-3">
              <h2 className="font-display text-2xl font-bold uppercase leading-none">Season schedule</h2>
              <p className="text-sm text-muted">Dates the league is planning. Brackets show up closer to the weekend.</p>
              {announced.map((item) => (
                <article key={item.weekend.id} className="site-card">
                  <h3 className="font-display text-2xl font-bold uppercase leading-none">{item.weekend.name}</h3>
                  <p className="mt-2 text-sm text-muted">{formatWeekendRange(item.weekend.startDate, item.weekend.endDate)}</p>
                  <p className="mt-1 text-sm text-muted">Dates are set. {interestCopy(item.weekend.interestCount)}</p>
                  {profile.homeRole === "coach" ? (
                    <InterestForm
                      weekendId={item.weekend.id}
                      mine={(interestQuery.data ?? []).filter((row) => row.weekendId === item.weekend.id)}
                    />
                  ) : null}
                </article>
              ))}
            </section>
          ) : null}
          {playing.map((item) => (
            <section key={item.weekend.id} className="space-y-3">
              <div>
                <h2 className="font-display text-2xl font-bold uppercase leading-none">{item.weekend.name}</h2>
                <p className="mt-2 text-sm text-muted">
                  {formatWeekendRange(item.weekend.startDate, item.weekend.endDate)}
                </p>
                {item.games.length > 0 ? (
                  <Link
                    to="/bracket/$weekendId"
                    params={{ weekendId: String(item.weekend.id) }}
                    className="mt-3 flex min-h-12 w-full items-center justify-center rounded-full bg-primary px-5 text-sm font-bold uppercase tracking-wide text-primary-fg"
                  >
                    Open Bracket
                  </Link>
                ) : null}
              </div>
              {item.games.length === 0 ? (
                <p className="rounded-lg border border-line bg-surface px-4 py-4 text-sm text-muted">
                  No games on the clock yet.
                </p>
              ) : (
                item.games.map((game) => (
                  <article key={game.id} className="site-card">
                    <p className="text-xs font-semibold uppercase tracking-wide text-muted">
                      {game.ageGroup} · {game.roundLabel}
                    </p>
                    <p className="mt-1 font-display text-2xl font-bold uppercase leading-none">
                      {game.homeName ?? "TBD"} vs {game.awayName ?? "TBD"}
                    </p>
                    <p className="mt-2 text-sm font-medium">{game.when}</p>
                    <p className="mt-1 text-sm text-muted">{game.locationName ?? "Field TBD"}</p>
                  </article>
                ))
              )}
            </section>
          ))}
        </div>
      )}
    </AppShell>
  );
}

function interestCopy(count: number) {
  if (count === 0) return "No teams interested yet.";
  return count === 1 ? "1 team interested." : `${count} teams interested.`;
}

function InterestForm({ weekendId, mine }: { weekendId: number; mine: { id: number; teamName: string }[] }) {
  const queryClient = useQueryClient();
  const [teamName, setTeamName] = useState("");
  const save = useMutation({
    mutationFn: () => showInterest({ data: { weekendId, teamName: teamName.trim() } }),
    onSuccess: async () => {
      setTeamName("");
      await queryClient.invalidateQueries({ queryKey: ["my-interest"] });
      await queryClient.invalidateQueries({ queryKey: ["my-schedule"] });
      await queryClient.invalidateQueries({ queryKey: ["weekends"] });
    },
  });
  const error = save.error instanceof Error ? save.error.message : null;
  return (
    <form
      className="mt-3 space-y-2"
      onSubmit={(event) => {
        event.preventDefault();
        if (!teamName.trim()) return;
        save.mutate();
      }}
    >
      {mine.length > 0 ? (
        <p className="text-sm font-semibold">{mine.map((row) => row.teamName).join(", ")} — interested.</p>
      ) : (
        <p className="text-sm text-muted">Put a team name in if you want to play. This is not a spot yet.</p>
      )}
      <Input value={teamName} onChange={(event) => setTeamName(event.target.value)} placeholder="Team name" maxLength={80} />
      {error ? <p className="text-sm text-fg">{error}</p> : null}
      <Button type="submit" className="w-full" disabled={save.isPending || !teamName.trim()}>
        {save.isPending ? "Saving…" : "We're interested"}
      </Button>
    </form>
  );
}
