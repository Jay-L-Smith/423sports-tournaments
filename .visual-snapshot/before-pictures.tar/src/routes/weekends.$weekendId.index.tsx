import { useMutation, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { SectionLink, WeekendAdminFrame, bumpWeekend } from "@/components/weekend-admin";
import { Button } from "@/components/ui/button";
import { deleteWeekend, promoteTournament, resolveLockout, resolveSeedConflict } from "@/lib/pbi/api";
import { ADVANCE_LABELS, ELIMINATION_LABELS } from "@/lib/pbi/rules";
import { formatAgeGroups, formatWeekendRange, isoDateFromLocal, lockoutDue } from "@/lib/pbi/weekends";

export const Route = createFileRoute("/weekends/$weekendId/")({
  component: TournamentHubPage,
});

function TournamentHubPage() {
  const { weekendId } = Route.useParams();
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const id = Number.parseInt(weekendId, 10);
  const [confirmDelete, setConfirmDelete] = useState(false);

  const lockMut = useMutation({
    mutationFn: (choice: "keep" | "smaller") => resolveLockout({ data: { weekendId: id, choice } }),
    onSuccess: () => bumpWeekend(queryClient, id),
  });
  const seedMut = useMutation({
    mutationFn: (input: { action: "keep" | "reseed"; confirm?: boolean }) =>
      resolveSeedConflict({ data: { weekendId: id, ...input } }),
    onSuccess: () => bumpWeekend(queryClient, id),
  });
  const deleteMut = useMutation({
    mutationFn: () => deleteWeekend({ data: { weekendId: id } }),
    onSuccess: async () => {
      await navigate({ to: "/" });
      await queryClient.invalidateQueries({ queryKey: ["weekends"] });
      await queryClient.invalidateQueries({ queryKey: ["season-cards"] });
      await queryClient.invalidateQueries({ queryKey: ["season-plan"] });
      await queryClient.invalidateQueries({ queryKey: ["my-schedule"] });
      await queryClient.invalidateQueries({ queryKey: ["my-teams"] });
    },
  });
  const promoteMut = useMutation({
    mutationFn: () => promoteTournament({ data: { weekendId: id } }),
  });

  return (
    <WeekendAdminFrame weekendId={weekendId} backTo="list">
      {({ detail }) => {
        const today = isoDateFromLocal(new Date());
        const announced = detail.lifecycle === "announced";
        const lockedOut = !announced && lockoutDue(detail.startDate, today, detail.rules.dropCutoffDays, detail.createdAt) && detail.hasBracket;
        const under = detail.approvedCount < detail.maxTeams;
        const error =
          (lockMut.error instanceof Error && lockMut.error.message) ||
          (seedMut.error instanceof Error && seedMut.error.message) ||
          (deleteMut.error instanceof Error && deleteMut.error.message) ||
          (promoteMut.error instanceof Error && promoteMut.error.message) ||
          null;
        return (
          <div className="flex min-h-[calc(100dvh-11rem)] flex-col">
            <div className="mt-3">
              <h1 className="font-display text-4xl font-bold uppercase">{detail.name}</h1>
              <p className="mt-1 text-sm font-medium">{formatWeekendRange(detail.startDate, detail.endDate)}</p>
            </div>
            {announced ? (
              <div className="mt-3 space-y-2">
                <p className="text-sm font-semibold">Not finalized.</p>
                <p className="text-sm text-muted">
                  {detail.interestCount === 0
                    ? "Waiting to see which teams are interested."
                    : detail.interestCount === 1
                      ? "1 team is interested. Finalize when you know the size."
                      : `${detail.interestCount} teams are interested. Finalize when you know the size.`}
                </p>
                <Button type="button" className="w-full" disabled={promoteMut.isPending} onClick={() => promoteMut.mutate()}>
                  {promoteMut.isPending ? "Sending…" : "Promote tournament"}
                </Button>
                {promoteMut.data ? (
                  <p className="text-sm text-muted">
                    {promoteMut.data.sent === 0
                      ? "No coaches on the app yet."
                      : promoteMut.data.sent === 1
                        ? "Sent to 1 coach."
                        : `Sent to ${promoteMut.data.sent} coaches.`}
                  </p>
                ) : null}
                <Link
                  to="/weekends"
                  search={{ add: 1, announce: detail.id }}
                  className="flex min-h-12 w-full items-center justify-center rounded-full border border-line bg-surface px-5 text-sm font-bold uppercase tracking-wide text-fg"
                >
                  Finalize tournament
                </Link>
              </div>
            ) : (
              <p className="mt-1 text-sm text-muted">
                {formatAgeGroups(detail.ageGroups) || "No ages yet"} · {detail.approvedCount}/{detail.maxTeams} in
              </p>
            )}

            {detail.placeConflict ? (
              <div className="mt-4 rounded-md border border-line bg-surface p-3">
                <p className="text-sm font-semibold">A pool score can move a frozen seed.</p>
                <p className="mt-1 text-xs text-muted">Keep the original seeds, or reseed. Reseed asks again if bracket games already have a result.</p>
                <div className="mt-3 flex gap-2">
                  <Button type="button" variant="outline" className="flex-1" disabled={seedMut.isPending} onClick={() => seedMut.mutate({ action: "keep" })}>
                    Keep original
                  </Button>
                  <Button
                    type="button"
                    className="flex-1"
                    disabled={seedMut.isPending}
                    onClick={() =>
                      seedMut.mutate({
                        action: "reseed",
                        confirm: seedMut.error instanceof Error && seedMut.error.message.includes("Confirm"),
                      })
                    }
                  >
                    {seedMut.error instanceof Error && seedMut.error.message.includes("Confirm") ? "Reseed anyway" : "Reseed"}
                  </Button>
                </div>
              </div>
            ) : null}

            {lockedOut && detail.lockoutChoice == null ? (
              <div className="mt-4 rounded-md border border-line bg-surface p-3">
                <p className="text-sm font-semibold">
                  {under
                    ? `${detail.approvedCount} of ${detail.maxTeams} are in. Keep this sheet, or rebuild it smaller.`
                    : `All ${detail.maxTeams} teams are in. Confirm this sheet.`}
                </p>
                <div className="mt-3 flex gap-2">
                  <Button type="button" variant="outline" className="flex-1" disabled={lockMut.isPending} onClick={() => lockMut.mutate("keep")}>
                    {under ? "Keep this sheet" : "Confirm"}
                  </Button>
                  {under ? (
                    <Button type="button" className="flex-1" disabled={lockMut.isPending} onClick={() => lockMut.mutate("smaller")}>
                      Rebuild smaller
                    </Button>
                  ) : null}
                </div>
              </div>
            ) : null}

            {error ? (
              <p className="mt-3 rounded-md bg-warn-bg px-3 py-2 text-sm" role="alert">
                {error}
              </p>
            ) : null}

            {announced ? null : (
              <Link
                to="/bracket/$weekendId"
                params={{ weekendId: String(detail.id) }}
                aria-label={detail.hasPoolGames || detail.hasBracket ? "Open bracket" : "Build bracket"}
                className="mt-4 flex min-h-0 flex-1 items-center"
              >
                <BracketPicture />
              </Link>
            )}

            <div className={announced ? "" : "mt-4 shrink-0"}>
            {announced ? null : (
              <nav className="grid w-full grid-cols-2 gap-2" aria-label="Tournament sections">
                <SectionLink to="/weekends/$weekendId/edit" weekendId={weekendId} title="Info" hint="Name, dates, ages" />
                <SectionLink
                  to="/weekends/$weekendId/rules"
                  weekendId={weekendId}
                  title="Rules"
                  hint={`${ELIMINATION_LABELS[detail.rules.elimination]} · ${ADVANCE_LABELS[detail.rules.advance]}`}
                />
                <SectionLink
                  to="/weekends/$weekendId/teams"
                  weekendId={weekendId}
                  title="Teams"
                  hint={detail.approvedCount === 0 ? "No clubs yet" : `${detail.approvedCount}/${detail.maxTeams} in`}
                />
                <SectionLink
                  to="/weekends/$weekendId/locations"
                  weekendId={weekendId}
                  title="Parks"
                  hint={detail.locations.length === 0 ? "Add parks" : `${detail.locations.length} park${detail.locations.length === 1 ? "" : "s"}`}
                />
              </nav>
            )}

            {confirmDelete ? (
              <div className="mt-6 rounded-md bg-warn-bg p-3">
                <p className="text-sm font-semibold">
                  {announced ? `Take ${detail.name} off the schedule?` : `Delete ${detail.name}?`}
                </p>
                <p className="mt-1 text-sm text-muted">
                  {announced
                    ? "Nothing else is built yet. This can’t be undone."
                    : "Teams, the bracket, and scores for this weekend come off the board. This can’t be undone."}
                </p>
                <div className="mt-3 flex gap-2">
                  <Button type="button" variant="outline" className="flex-1" disabled={deleteMut.isPending} onClick={() => setConfirmDelete(false)}>
                    Keep it
                  </Button>
                  <Button type="button" variant="danger" className="flex-1" disabled={deleteMut.isPending} onClick={() => deleteMut.mutate()}>
                    {deleteMut.isPending ? "Deleting…" : "Delete"}
                  </Button>
                </div>
              </div>
            ) : (
              <Button type="button" variant="ghost" className="mt-4 w-full text-muted" onClick={() => setConfirmDelete(true)}>
                Delete tournament
              </Button>
            )}
            </div>
          </div>
        );
      }}
    </WeekendAdminFrame>
  );
}

function BracketPicture() {
  return (
    <img
      src="/bracket-sheet.jpg"
      alt=""
      className="max-h-full w-full object-contain"
    />
  );
}
